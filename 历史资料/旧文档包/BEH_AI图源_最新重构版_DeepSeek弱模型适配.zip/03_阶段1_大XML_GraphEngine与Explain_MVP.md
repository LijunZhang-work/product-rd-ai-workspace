# 阶段1：大 XML Graph Engine 与 Explain MVP

## 1. 阶段目标

这是当前最紧急阶段。

目标不是做完整 BEH 编辑器。

只要实现：

> **从几十 MB BEH XML 中稳定抽取局部 Reviewed Graph，让人和 AI 在同一张原始坐标图上理解局部图源。**

---

# 2. 当前已有能力

可复用：

- `_location` 元素提取；
- XML 基础读取；
- 现有 HTML 原型；
- 矩形框选思路；
- 当前 relation / continuation 初步解析；
- DOT簇图实验。

---

# 3. 需要停止的做法

停止：

```text
每次出错
→ AI重新进几十MB XML找原因
```

停止：

```text
Renderer自己扫描XML找Edge
```

停止：

```text
AI看到dot图后反推原XML哪里错
```

---

# 4. Graph Engine

参考 graph-first 思想，构建固定工具：

```text
BEH XML
↓
Streaming Parser
↓
Persistent Index / Graph Store
```

至少建立：

```text
ElementById
ParentIndex
ChildrenIndex
ForwardReferenceIndex
ReverseReferenceIndex
LocationIndex
RelationCandidateIndex
ScopeIndex
```

---

# 5. Graph Store

第一版可用：

```text
SQLite
+
JSON snapshot
```

目标：

> XML只解析一次。

以后：

```text
query_node(N173)
query_refs(N173)
query_relation(R27)
query_neighbors(N173)
query_scope(N173)
```

不重新扫全文件。

---

# 6. Relation Family

不要假设所有线只有一种结构。

查询器需要自动统计：

```text
Relation Family #1
Relation Family #2
Continuation Family
Unknown Reference Family
```

特征：

- XML tag；
- 父级；
- 属性集合；
- 引用数量；
- 引用对象类型；
- 是否有location；
- Scope；
- 子结构。

AI可以帮助归纳 Family，但 Family 特征由程序统计。

---

# 7. Raw Candidate → Graph IR

流程：

```text
Raw XML
↓
Candidate Nodes / Refs / Relations
↓
Normalizer
↓
Graph IR
```

Graph IR至少：

```text
Node
Port
VisibleEdgeCandidate
BoundaryCandidate
ImplicitLink
Unknown
Evidence
```

---

# 8. Edge Provenance

任何候选线必须保存：

```text
candidate_edge_id
origin_xml_object
relation_id
xml_path
parser_rule
source_candidate
target_candidate
scope
evidence
```

后面画错时可以立即追根。

---

# 9. Review Gate

Edge状态：

```text
DISCOVERED
↓
NORMALIZED
↓
VALIDATED
↓
APPROVED
↓
RENDERED
```

也可以：

```text
REJECTED
UNKNOWN
```

禁止：

```text
DISCOVERED → RENDERED
```

---

# 10. Original View

迁移到：

```text
Sprotty + SVG
```

Node：

```text
直接使用_location
```

Edge：

```text
只读取APPROVED VisibleEdge
```

Renderer禁止创造关系。

---

# 11. 三显示模式

支持：

```text
BEH视觉
混合
内部
```

用于人工对照。

---

# 12. 圈选

支持：

```text
矩形
椭圆
Lasso
```

执行 Graph Hit Test。

Selection Pack：

```json
{
  "selection_id": "...",
  "nodes": [],
  "edges": [],
  "boundary_edges": [],
  "implicit_links": [],
  "parameters": [],
  "evidence_refs": []
}
```

---

# 13. AI Explain 输入

旧 V4 Flash 不拿原始 XML。

给：

```text
Selection Pack
+
少量必要Evidence
+
当前节点显示名称
+
可选SVG局部摘要（视觉模型后期再加）
```

文本量控制小。

---

# 14. AI Explain 输出固定Schema

```json
{
  "summary": "",
  "beginner_explanation": "",
  "professional_explanation": "",
  "inputs": [],
  "processing_steps": [],
  "outputs": [],
  "uncertainties": [],
  "evidence_refs": []
}
```

不要自由散文作为机器链路输入。

UI可以再渲染成自然语言。

---

# 15. AI角色

阶段1 V4 Flash只负责：

```text
理解结构化局部
给小白解释
标记不确定
```

不负责：

```text
决定哪根relation存在
决定relation_id
修改Graph
```

---

# 16. 查询工具

为 Harness 后续提前设计：

```text
get_node
get_edge
get_neighbors
get_scope
get_edge_evidence
get_selection_pack
find_reference_paths
```

但阶段1不一定马上接Harness。

先让工具本身可独立运行。

---

# 17. 阶段1验收

用至少 10 个用户人工能确认的小簇。

要求：

1. Node位置基本对；
2. Graph IR可审计；
3. Renderer不创造Edge；
4. 圈选返回正确Node/Edge ID；
5. Explain能基本讲对；
6. 错误线可以从UI追到原XML origin；
7. 不需要把几十MB XML给AI。

---

# 18. 阶段1结束时不要追求

不要求：

```text
所有BEH relation family都100%识别
```

允许：

```text
UNKNOWN
```

目标是：

> 系统开始“可收敛”，而不是继续黑盒猜。
