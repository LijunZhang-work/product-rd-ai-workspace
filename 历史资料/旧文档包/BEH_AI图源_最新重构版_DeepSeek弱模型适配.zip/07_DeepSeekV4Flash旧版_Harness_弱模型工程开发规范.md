# DeepSeek V4 Flash 旧版 + DeepSeek Harness + 小视觉模型：弱模型工程开发规范

## 1. 本规范为什么单独存在

本项目不能按照最强模型设计。

公司侧按以下保守假设：

> **使用较早的 DeepSeek V4 Flash，而不是后来正式增强 Agent 能力的版本。**

因此：

```text
任何关键正确性
不能依赖模型“自己想明白”
```

必须依赖：

```text
工具
Schema
状态机
测试
验证
Evidence
```

---

# 2. 对旧 V4 Flash 的定位

把它当作：

```text
不错的文本推理器
+
工具调用Planner
+
代码/规则辅助分析器
```

不要把它当作：

```text
Computer Use原生多模态Agent
复杂视觉模型
大XML数据库
可靠形式化验证器
```

---

# 3. API能力保守原则

不要依赖后续版本才增强的功能。

主接入优先使用：

```text
DeepSeek ChatCompletions / Harness自带DeepSeek Adapter
```

不要把系统架构绑定在：

```text
最新Responses API
最新thinking effort档位
最新Agent benchmark能力
```

公司旧端点未必具备相同行为。

---

# 4. Harness定位

使用 DeepSeek 官方 Harness：

```text
Agent shell
Plugin system
Tool registry
Workspace
Model adapter
```

但 Harness目前属于：

```text
Developer Preview
```

可能发生兼容性变化。

因此：

> Harness不是业务核心。

---

# 5. 三角色架构

参考 Harness capability layering，把能力拆成：

```text
Service Definition
Service Provider
Tool Consumer
```

例如：

```text
BehGraphService
↓
LocalGraphProvider
↓
beh_get_edge Tool
```

以后可以替换 Provider，而不用改模型Tool契约。

---

# 6. 推荐Service

```text
BehGraphService
BehXmlEvidenceService
BehVisionService
BehUiAutomationService
BehVerificationService
BehProposalService
```

---

# 7. Tool必须窄

好工具：

```text
get_edge(edge_id)
get_neighbors(node_id)
capture_region(rect)
double_click(point)
read_dialog()
compare_relation_id()
```

坏工具：

```text
analyze_everything_and_fix_the_diagram()
```

---

# 8. Tool参数必须显式

用：

```text
enum
ID
boolean
small object
```

减少：

```text
自由自然语言参数
```

例如：

```json
{
  "edge_id": "E17",
  "candidate_index": 1
}
```

而不是：

```text
“帮我大概点一下A和B之间那条看起来比较像的线”
```

---

# 9. Tool结果必须固定Schema

例如：

```json
{
  "result": "PASS",
  "actual_relation_id": "relation_2",
  "evidence_id": "EV-22"
}
```

不要返回长篇自然语言给Agent。

---

# 10. 一轮只做一个决定

旧弱模型避免：

```text
一次决定10步
```

采用：

```text
Observe
↓
Decide one action
↓
Execute
↓
Observe result
↓
Decide next
```

---

# 11. 强状态机

Agent流程一定有状态：

```text
READY
CONTEXT_LOADED
VISUAL_LOCALIZED
ACTION_EXECUTED
DIALOG_READ
VERIFIED
FAILED
```

不允许模型跳过必要阶段。

---

# 12. 不使用超大Context作为能力补偿

即使端点允许很长上下文：

也不要：

```text
把50MB XML文本化后塞进去
```

长上下文不是数据库替代品。

优先：

```text
Graph Query Tool
```

---

# 13. AI输出先Schema Validation

任何：

```text
Explain
Proposal
Rule Hypothesis
Action Plan
```

都先过 JSON Schema。

解析失败：

```text
retry with repair
```

不要直接进入业务系统。

---

# 14. AI结论分三类

```text
FACT
INFERENCE
UNKNOWN
```

例如：

```json
{
  "direction": "A_TO_B",
  "status": "INFERENCE",
  "evidence": ["EV1","EV2"]
}
```

不要把推测伪装成事实。

---

# 15. AI不能创建Verified Edge

AI只能：

```text
提出 Candidate
```

固定 Review Engine 才能：

```text
APPROVE
```

---

# 16. 小视觉模型的正确用法

视觉模型输入应该：

```text
裁剪
少目标
任务单一
```

例如：

```text
“找这个局部里可能被双击的线段中点。”
```

不要：

```text
“解释这张完整复杂PLC图。”
```

---

# 17. 视觉输出Schema

```json
{
  "candidates": [
    {
      "point": [123,456],
      "confidence": 0.76,
      "reason_code": "LONG_STRAIGHT_SEGMENT"
    }
  ]
}
```

坐标转换、点击由固定工具执行。

---

# 18. Vision不能负责文字精确核验

relation_id优先：

```text
UIA/JAB
Clipboard
```

视觉OCR只兜底。

---

# 19. 计划与执行分离

V4 Flash可以规划：

```text
需要核验E17
→ 先获取geometry
→ 再截图
```

但执行工具自己检查参数合法性。

---

# 20. 失败必须显式结束

每个任务设：

```text
max_steps
max_retries
timeout
```

超过：

```text
UNRESOLVED
```

不要循环到模型自我迷失。

---

# 21. 关键事实Exact Compare永远程序化

包括：

```text
relation_id
node_id
parameter value
file hash
Graph operation count
```

绝不让模型回答：

```text
“看起来一样。”
```

---

# 22. AI Debug依赖Evidence，不依赖图片猜测

模型看到：

```text
Edge E17
origin relation_10
scope=N2
source=A
target=B
```

再做分析。

不要只发：

```text
DOT截图
“你看看哪里错了？”
```

---

# 23. 日志

每次Agent任务保存：

```text
task_id
model
prompt_version
tool calls
tool results
screenshots
final result
elapsed time
```

---

# 24. Prompt版本化

System / SOP：

```text
VERIFY_RELATION_SOP_V3
EXPLAIN_CLUSTER_SOP_V2
COMPOSE_GRAPH_SOP_V1
```

修改后跑回归。

---

# 25. 模型可替换

业务接口不要出现：

```text
deepseek_v4_specific_relation_parser()
```

模型只在：

```text
Agent / LLM Adapter
```

层。

以后可以换：

```text
更强DeepSeek
GPT
Kimi
其他模型
```

---

# 26. Harness升级风险

因为官方 Harness 是 Developer Preview：

- 锁定已验证版本；
- 记录版本号；
- Plugin契约自己封装；
- 不让业务代码直接大量依赖内部API；
- 升级前运行完整验图回归。

---

# 27. 推荐Harness中模型分工

```text
Main Agent
= V4 Flash旧版

Vision Tool Provider
= 小视觉模型

Optional Rule Analyst
= 也可用V4 Flash thinking模式（若公司端点支持且稳定）
```

不要建立“多Agent互相聊天”的复杂系统。

弱模型下：

> 少Agent、强工具、清状态，比多Agent辩论更可靠。

---

# 28. 最适合旧V4 Flash的项目哲学

```text
模型不记住事实
→ 工具查

模型不计算图
→ 程序算

模型不比较ID
→ 程序比

模型不处理大XML
→ 索引查

模型不直接改正式图
→ Proposal

视觉模型不理解业务
→ 只定位

Harness不保存业务真相
→ Graph IR保存
```

---

# 29. 一句话

> **把旧 V4 Flash 当“会调用工具的工程助理”，而不是“万能智能体”；系统能力尽量固化在 Graph Engine、Review Engine、Native Verifier 和明确的工具契约里。**
