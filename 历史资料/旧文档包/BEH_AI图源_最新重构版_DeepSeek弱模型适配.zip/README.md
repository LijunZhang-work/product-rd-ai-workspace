# BEH AI 图源项目：最新重构版文档集

本目录是对此前以下几类文档的重新梳理与合并：

- 《BEH 人机统一图源工作台设计书》
- 《BEH 图元簇结构化 Graph IR 与可审计 Review 设计》
- 之前的“总路线图 + 5 个阶段”
- BEH 原生程序 AI 接入能力检测指南
- PLC / 标准 XML 指纹检测与私有格式分析思路
- Relation / Continuation / 箭头方向研究
- Computer Use / 原生 BEH 自动验图讨论
- DeepSeek Harness + 小视觉模型协作讨论
- Graphify 的 graph-first / provenance / query 思想

## 本次重构后的核心判断

1. **BEH XML 主要是自研私有语言。**
   - IEC 61131-3 更适合作为“PLC 语义参考”，而不是直接拿标准 XML Schema 硬套 BEH。
   - 标准 XML 指纹检测仍有价值，但降级为辅助研究工具，不再阻塞主线开发。

2. **当前最紧急目标是“让 AI 读懂图源”，不是先做完整 AI 写图源。**
   - 先把几十 MB XML 一次解析成可查询 Graph Engine；
   - 把带 `_location` 的图元与经过 Review 的 Relation 合成同一张原始坐标图；
   - 人和 AI 共同围绕同一份 Graph IR 工作。

3. **DeepSeek V4 Flash 按旧版/Preview 级能力保守设计。**
   - 不依赖最新正式版增强的 Agent 能力；
   - 不依赖最新 Responses API；
   - 不让模型直接处理几十 MB XML；
   - 大量确定性工作必须工具化。

4. **DeepSeek Harness 是 Agent 外壳，不是“自动变强器”。**
   - Harness 用于插件、工具、工作区、任务编排；
   - 小视觉模型作为独立“眼睛”；
   - V4 Flash 作为文本规划器；
   - Parser / Graph / Review / Compare 都由固定程序负责。

## 最新文档

1. `00_旧文档重构说明与最新文档地图.md`
2. `01_BEH_AI图源工作台_最新总体设计书.md`
3. `02_BEH_AI图源项目_DeepSeek弱模型适配开发路线图.md`
4. `03_阶段1_大XML_GraphEngine与Explain_MVP.md`
5. `04_阶段2_Relation结构化Review与原生BEH核验.md`
6. `05_阶段3_DeepSeekHarness_小视觉模型_自动验图Agent.md`
7. `06_阶段4_Compose人机共创与AI写图源.md`
8. `07_DeepSeekV4Flash旧版_Harness_弱模型工程开发规范.md`

## 建议使用顺序

先读：

```text
01 总体设计书
↓
02 总路线图
```

然后按开发阶段：

```text
03 → 04 → 05 → 06
```

`07` 是所有阶段都要遵守的模型/Agent 开发规范。
