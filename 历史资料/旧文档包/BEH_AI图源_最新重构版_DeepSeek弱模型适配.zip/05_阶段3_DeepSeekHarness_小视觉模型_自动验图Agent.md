# 阶段3：DeepSeek Harness + 小视觉模型自动验图 Agent

## 1. 阶段前提

只有阶段2固定工具已经可用，才进入本阶段。

否则：

> AI Agent只会把不稳定工具的错误放大。

---

# 2. 目标

实现：

```text
Suspicious Verification Task
↓
V4 Flash Planner
↓
Harness Tools
↓
Small Vision Localizer
↓
BEH操作
↓
Native Property
↓
Fixed Compare
↓
PASS / MISMATCH / UNRESOLVED
```

---

# 3. 模型角色

## DeepSeek V4 Flash旧版

只做：

```text
任务规划
工具选择
状态判断
有限重试
异常归纳
```

不做：

```text
视觉
exact compare
大XML检索
Graph算法
桌面底层操作
```

---

## 小视觉模型

只做：

```text
局部截图定位
简单控件分类
候选线段定位
弹窗视觉确认
```

不做：

```text
整个PLC图理解
业务逻辑推理
复杂relation规则总结
```

---

# 4. Harness角色

使用官方 DeepSeek Harness 的：

```text
Plugin
Tool
Service
Agent loop
Workspace
```

作为统一编排外壳。

业务核心不能锁死在Harness内部。

---

# 5. 推荐Harness插件

```text
dsh-beh-graph
dsh-beh-verify
dsh-beh-vision
dsh-beh-ui
dsh-beh-report
```

---

# 6. Graph工具

例如：

```text
beh_get_node
beh_get_edge
beh_get_edge_evidence
beh_get_verification_task
beh_get_geometry
beh_get_neighbors
```

返回小而稳定的 JSON。

---

# 7. UI工具

```text
beh_capture_window
beh_capture_region
beh_double_click
beh_send_keys
beh_read_clipboard
beh_read_dialog
beh_close_dialog
```

---

# 8. Vision工具

不要把视觉模型直接挂成主Agent。

包装成：

```text
beh_vision_locate
```

输入：

```json
{
  "image": "...",
  "task": "LOCATE_EDGE_SEGMENT",
  "source_anchor": {},
  "target_anchor": {}
}
```

输出固定：

```json
{
  "candidates": [
    {"x": 320, "y": 210, "confidence": 0.72},
    {"x": 340, "y": 235, "confidence": 0.44}
  ]
}
```

---

# 9. Vision Provider

Harness 支持自定义 Provider。

小视觉模型配置为：

```text
text + image
```

V4 Flash仍使用文本 Provider。

两个模型不要混成同一个模型能力假设。

---

# 10. Agent状态机

强制状态：

```text
LOAD_TASK
↓
GET_GRAPH_CONTEXT
↓
CAPTURE
↓
LOCALIZE
↓
ACTION
↓
READ_RESULT
↓
COMPARE
↓
PASS / RETRY / UNRESOLVED
```

模型不能随意跳阶段。

---

# 11. 单步工具原则

旧 V4 Flash较弱。

工具要：

```text
一个工具只做一件事
参数少
枚举清晰
结果短
```

不要：

```text
verify_relation_and_retry_and_report_everything()
```

这种巨型工具。

---

# 12. 但也不要让模型做低层细节

例如：

```text
double_click(x,y)
```

是固定工具。

模型只决定：

```text
candidate_index=1
```

避免模型计算像素。

---

# 13. 上下文控制

即使模型上下文很大，也不要喂大上下文。

一个 Verification Task 只给：

```text
Edge ID
source / target
expected relation
source / target geometry
最近一次截图信息
最近一次action result
```

不要给几十MB XML。

---

# 14. 视觉裁剪

小视觉模型只看：

```text
source-target局部
```

例如：

```text
400×400
800×500
```

不要默认整屏识别。

---

# 15. 自我纠错依赖“环境反馈”

例如：

```text
视觉模型点错线
↓
弹窗actual=relation_10
expected=relation_2
↓
固定比较MISMATCH
↓
Planner知道“点错候选”
↓
尝试第二候选
```

不是让视觉模型第一次就100%准确。

---

# 16. Tool Result必须机器友好

不要返回：

```text
“看起来好像成功点击了。”
```

返回：

```json
{
  "action": "DOUBLE_CLICK",
  "executed": true,
  "dialog_detected": true,
  "dialog_type": "RELATION_PROPERTY"
}
```

---

# 17. 失败预算

每个对象：

```text
最多 N 次定位尝试
最多 N 次点击
最大运行时长
```

超过：

```text
UNRESOLVED
```

旧弱模型最怕无限循环。

---

# 18. 只读权限

本阶段 Agent只允许：

```text
View
Select
Double Click
Copy
Close
Zoom
Pan
```

禁止：

```text
Edit
Save
Delete
Apply
Generate
```

---

# 19. Harness作为可替换外壳

DeepSeek Harness目前属于开发者预览。

因此必须把业务能力写成稳定接口：

```text
GraphService
VisionService
UIService
VerificationService
```

Harness Plugin只是 Consumer / Adapter。

以后 Harness API变动，不影响业务核心。

---

# 20. 阶段3验收

至少：

```text
20 Node
30 Relation
```

比较人工结果。

要求：

- PASS/MISMATCH准确；
- 点错可重试；
- 无法确认返回UNRESOLVED；
- 不修改工程；
- 每一步有日志；
- 换视觉模型不改Graph Engine；
- 换V4模型不改Verification工具。

---

# 21. 一句话

> **让 V4 Flash负责“下一步怎么办”，让小视觉模型负责“局部在哪里”，让固定程序负责“事实到底是什么”。**
