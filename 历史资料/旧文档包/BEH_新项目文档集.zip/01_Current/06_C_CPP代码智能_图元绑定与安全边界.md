# C/C++ 代码智能、图元绑定与安全边界

## 1. 目标

当用户圈选图元后，AI 不仅解释图上的连接，还应结合整个代码仓回答：

- 输入来自哪个变量或函数；
- 每个元素依次做了什么；
- 输出流向哪里；
- 对应哪些 C/C++ 文件、函数和变量；
- 与圈外模块有什么联系；
- 哪些结论是事实，哪些只是推断。

---

## 2. 为什么必须使用真实编译上下文

C/C++ 文件不是自包含的。

准确解析依赖：

- include path；
- 宏；
- C / C++ 标准；
- 目标平台；
- 生成头文件；
- 编译器行为。

因此高精度模式必须优先使用：

```text
compile_commands.json
```

Web 必须显示精度状态：

```text
HIGH
DEGRADED
UNAVAILABLE
```

不得在缺少编译数据库时悄悄声称“已完整理解代码仓”。

---

## 3. 索引层级

### Level 0：文本搜索

工具：ripgrep。

用途：快速定位字符串。

### Level 1：语法结构

工具：Tree-sitter。

用途：

- 函数范围；
- 类 / 结构体；
- 基础语法树；
- 无完整编译环境时降级使用。

### Level 2：语义索引

工具：clangd / Clang Index。

用途：

- Definition；
- References；
- Types；
- Callers / Callees；
- 符号关系。

### Level 3：目标分析

工具：Clang Tooling。

用途：

- AST 查询；
- CFG；
- 局部 Def-Use；
- 参数 / 返回值传播；
- 特定模式分析。

### Level 4：运行时证据

后期可选：

- 日志；
- Trace；
- 测试执行；
- 动态采样。

静态分析无法证明的路径必须标记 UNKNOWN。

---

## 4. Scene-to-Code Binding

独立建立：

```text
Native Scene Object
↔
Code Symbol / File / Range
```

证据等级：

### DIRECT

原生 BEH 模型明确包含：

- 函数名；
- 变量名；
- 模块 ID；
- 代码文件；
- 生成代码映射。

### GENERATED_MAPPING

来自生成物清单或符号映射表。

### EXACT_SYMBOL

唯一同名符号，且类型 / Scope 匹配。

### DATAFLOW_INFERRED

通过调用图和数据流推断。

### HYPOTHESIS

由 AI 提出，尚未验证。

Web 必须展示等级，不得把 HYPOTHESIS 当事实。

---

## 5. 数据流解释结构

每一步至少输出：

```text
输入对象 / 变量
当前图元
当前操作
关键参数
输出对象 / 变量
下一跳
代码位置
Evidence
```

跨圈边界单独列：

```text
Incoming Boundary
Outgoing Boundary
Code Calls In
Code Calls Out
```

---

## 6. 代码索引性能

- 打开工作区时不阻塞场景查看；
- 代码索引后台执行；
- 显示进度；
- 支持取消；
- 基于 commit 和 compile DB hash 缓存；
- 优先返回局部结果；
- 超大仓库允许静态索引文件或远程索引，但不作为 MVP 必需。

---

## 7. 安全边界

### Web MVP

- 只读代码；
- 不直接修改文件；
- 不调用模型 API；
- 不上传仓库。

### AI Explain

- 只读工具；
- 禁止 shell 任意写；
- 代码引用必须带文件和范围；
- 结果包不包含不必要的大段源码。

### AI Develop

后期才开放：

- Proposal Patch；
- 独立临时工作树；
- 格式化；
- 编译；
- 单元测试；
- 人工确认；
- Apply / Rollback。

---

## 8. 敏感数据

任务包默认只包含：

- 相对路径；
- 符号 ID；
- 必要代码片段；
- Hash；
- Evidence Ref。

若 Skill 与工作区处于同一公司环境，可通过工具按需读仓库；不要复制整个仓库进任务包。

---

## 9. 代码解释限制

以下情况必须显式提示：

- 宏展开不完整；
- 外部库不可见；
- 生成代码缺失；
- 函数指针 / 虚调用存在多候选；
- 指针别名无法证明；
- 异步 / 线程顺序无法静态确定；
- 配置条件导致多路径；
- 当前编译 Profile 与真实运行不一致。
