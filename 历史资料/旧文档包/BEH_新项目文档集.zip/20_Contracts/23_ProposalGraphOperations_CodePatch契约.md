# Proposal Graph Operations 与 Code Patch 契约

## 1. 适用阶段

本契约只在 AI 解释和代码关联能力稳定后启用。

---

## 2. Proposal 顶层

```json
{
  "schema_version": "1.0.0",
  "proposal_id": "PROP_001",
  "task_id": "TASK_100",
  "status": "DRAFT",
  "graph_operations": [],
  "code_changes": [],
  "impact": {},
  "validation_plan": {},
  "uncertainties": []
}
```

---

## 3. Graph Operation

```json
{
  "operation_id": "OP_1",
  "op": "CREATE_NODE",
  "target_region_id": "ANN_3",
  "native_type_candidate": "TON",
  "temporary_id": "P_NODE_1",
  "position_hint": {"x":0,"y":0},
  "parameters": {},
  "preconditions": [],
  "evidence_ids": [],
  "risk": "LOW"
}
```

AI不得生成最终 native relation_id、内部 UUID 或隐藏字段。

---

## 4. Connect

```json
{
  "operation_id": "OP_2",
  "op": "CONNECT",
  "source_ref": "N17.OUT",
  "target_ref": "P_NODE_1.IN",
  "preconditions": ["PORT_TYPES_COMPATIBLE"]
}
```

---

## 5. Code Change

```json
{
  "change_id": "CH_1",
  "path": "src/alarm/freq_alarm.cpp",
  "kind": "MODIFY",
  "unified_diff": "...",
  "related_operation_ids": ["OP_1"],
  "reason": "...",
  "format_required": true,
  "build_targets": [],
  "tests": []
}
```

---

## 6. Impact

必须列：

- 圈内对象；
- 圈外对象；
- 新增 / 删除 Relation；
- 代码文件；
- 符号；
- 编译目标；
- 风险；
- 不支持项。

---

## 7. 状态机

```text
DRAFT
→ VALIDATED
→ REVIEWED
→ APPROVED
→ APPLIED
→ VERIFIED
```

也可能：

```text
REJECTED
FAILED
ROLLED_BACK
```

AI 只能创建 DRAFT。

---

## 8. Apply 门禁

Apply 前必须：

- Schema通过；
- Graph验证；
- Port验证；
- 代码Patch可应用；
- 格式化；
- 编译；
- 测试；
- 人工确认。

---

## 9. Round-trip

Apply 后必须重新导出场景并比较：

- Node；
- Port；
- Relation；
- 参数；
- 代码；
- Diagnostics。

---

## 10. 安全

- 在临时工作树应用；
- 禁止覆盖原始文件无备份；
- 每个 Proposal 可撤销；
- 记录命令和结果；
- 未验证组件不得自动生成。
