# Selection、Annotation 与 AnalysisTaskBundle 契约

## 1. 目的

准确表达：

- 人圈选了什么；
- 人在哪里圈；
- 人画了什么结构化标注；
- 人留下了什么自由笔；
- 人用文字要求分析什么；
- AI需要访问哪个工作区和代码仓。

任务包不是截图加一句话。

---

## 2. 目录

```text
TASK_001/input/
├── manifest.json
├── workspace-ref.json
├── analysis-request.json
├── selection.json
├── selected-subgraph.json
├── boundary-context.json
├── annotations.json
├── native-properties.json
├── code-access.json
├── preview.svg
└── diagnostics.json
```

---

## 3. selection.json

```json
{
  "schema_version": "1.0.0",
  "selection_id": "SEL_001",
  "scene_id": "SCENE_001",
  "geometry": {
    "type": "LASSO",
    "coordinate_space": "BEH_WORLD",
    "points": []
  },
  "policy": "INTERSECTS",
  "selected_node_ids": [],
  "selected_port_ids": [],
  "selected_relation_ids": []
}
```

selected IDs 由固定 Hit Test 计算，不由模型猜。

---

## 4. selected-subgraph.json

只包含选中对象和内部正式关系。

不得包含与 selection 无关的整张大图。

---

## 5. boundary-context.json

```json
{
  "incoming_relations": [],
  "outgoing_relations": [],
  "implicit_links": [],
  "external_nodes_summary": []
}
```

这是回答“和未圈选内容有什么联系”的核心。

---

## 6. annotations.json

### 结构化 Arrow

```json
{
  "annotation_id": "ANN_1",
  "type": "ARROW",
  "from": {"world_point":[],"near_native_id":"N17"},
  "to": {"world_point":[],"near_native_id":"N18"},
  "user_label": ""
}
```

### Text Note

```json
{
  "annotation_id": "ANN_2",
  "type": "TEXT_NOTE",
  "world_position": [],
  "text": "重点解释这里"
}
```

### Target Region

```json
{
  "annotation_id": "ANN_3",
  "type": "TARGET_REGION",
  "geometry": {},
  "purpose": "FUTURE_COMPOSE"
}
```

### Freehand

```json
{
  "annotation_id": "ANN_4",
  "type": "FREEHAND",
  "semantic_status": "UNRESOLVED",
  "strokes": [],
  "near_native_ids": []
}
```

自由笔不得自动升级成正式连接。

---

## 7. analysis-request.json

MVP：

```json
{
  "task_id": "TASK_001",
  "mode": "EXPLAIN",
  "user_request": "请解释圈选区域的数据流，并结合C/C++代码。",
  "requested_outputs": [
    "PROFESSIONAL",
    "BEGINNER",
    "DATA_FLOW_STEPS",
    "BOUNDARY_CONTEXT",
    "CODE_LINKS"
  ],
  "constraints": {
    "read_only": true,
    "must_cite_evidence": true,
    "allow_unknown": true
  }
}
```

开发阶段才允许：

```text
mode = DEVELOP
```

---

## 8. workspace-ref.json

```json
{
  "workspace_id": "WS_001",
  "repo_root_ref": "LOCAL_WORKSPACE",
  "repo_commit": "...",
  "entry_xml_ref": "...",
  "canvas_id": "POU_MAIN",
  "compile_commands_ref": "..."
}
```

默认不复制整个代码仓。

---

## 9. code-access.json

描述 Skill 可以调用的只读工具及精度：

```json
{
  "precision": "HIGH",
  "available_tools": [
    "find_symbol",
    "find_references",
    "find_callers",
    "get_code_context"
  ]
}
```

---

## 10. 准确性规则

- 圈选 ID 是事实；
- Structured Annotation 是用户明确意图；
- Freehand 是原始笔迹；
- Preview 仅供视觉参考，不是选择真值；
- 用户文字不能覆盖原生场景事实；
- Task Bundle 必须先 Schema Validate。
