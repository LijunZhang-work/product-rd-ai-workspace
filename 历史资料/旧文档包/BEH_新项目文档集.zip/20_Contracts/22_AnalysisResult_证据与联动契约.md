# AnalysisResult、证据与 Web 联动契约

## 1. 目的

让 Web 不需要理解 AI 的自由文本，也能准确知道：

- AI 当前讲哪个图元；
- 哪根 Relation；
- 哪段代码；
- 哪个结论有何证据；
- 哪些内容不确定。

---

## 2. 目录

```text
TASK_001/output/
├── result.json
├── report.md
├── evidence-index.json
└── diagnostics.json
```

---

## 3. result.json 顶层

```json
{
  "schema_version": "1.0.0",
  "task_id": "TASK_001",
  "status": "COMPLETE",
  "summary": {},
  "inputs": [],
  "steps": [],
  "outputs": [],
  "boundary_links": [],
  "code_paths": [],
  "uncertainties": [],
  "evidence_refs": []
}
```

---

## 4. 步骤结构

```json
{
  "step_no": 3,
  "title": "延时确认",
  "focus_refs": {
    "node_ids": ["TON_17"],
    "port_ids": [],
    "relation_ids": ["R8", "R9"],
    "code_refs": ["CODE_203"]
  },
  "input": {},
  "operation": {},
  "output": {},
  "professional_explanation": "",
  "beginner_explanation": "",
  "evidence_ids": ["EV_1"],
  "confidence": "HIGH"
}
```

---

## 5. Evidence

```json
{
  "evidence_id": "EV_1",
  "kind": "NATIVE_SCENE",
  "source_ref": "R8",
  "claim": "TON_17 接收来自比较器的输入",
  "status": "DIRECT"
}
```

Evidence kind：

```text
NATIVE_SCENE
NATIVE_PROPERTY
CODE_SYMBOL
CODE_REFERENCE
CALL_GRAPH
DATA_FLOW
USER_ANNOTATION
AI_INFERENCE
```

Evidence status：

```text
DIRECT
DERIVED
HYPOTHESIS
```

---

## 6. Code Ref

```json
{
  "code_ref": "CODE_203",
  "path": "src/alarm/freq_alarm.cpp",
  "start_line": 203,
  "end_line": 208,
  "symbol_id": "SYM_17",
  "precision": "HIGH"
}
```

---

## 7. Web 联动规则

点击 Step：

- `focus_refs.node_ids` 高亮；
- `relation_ids` 高亮；
- 其他对象淡化；
- 代码抽屉跳转；
- 视图自动聚焦但保留用户返回路径。

点击画布对象：

- 找到包含该 ID 的 Step；
- 右侧滚动定位；
- 显示证据。

点击代码：

- 高亮绑定图元；
- 定位步骤。

---

## 8. 专业版与小白版

必须共享相同：

- Step；
- focus_refs；
- Evidence；
- Input / Output。

只能改变解释语言，不得产生两套不同事实。

---

## 9. UNKNOWN

```json
{
  "uncertainty_id": "U1",
  "topic": "跨线程后续影响",
  "reason": "静态证据不足",
  "needed_evidence": ["runtime_trace"]
}
```

UNKNOWN 必须在 UI 可见。

---

## 10. 校验

- 所有 focus ID 必须存在；
- Evidence ID 必须可解析；
- Step No 唯一且有序；
- Professional/Beginner 不得缺事实字段；
- Result 不得包含未声明的正式 Graph 修改。
