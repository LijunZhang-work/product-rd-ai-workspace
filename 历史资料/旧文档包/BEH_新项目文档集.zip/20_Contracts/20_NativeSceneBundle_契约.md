# NativeSceneBundle 契约

## 1. 目的

定义 BEH Headless Native Scene Service 与 Web / AI 之间的唯一场景交换格式。

---

## 2. 目录

```text
NativeSceneBundle/
├── manifest.json
├── scene.svg
├── scene.json
├── hit-map.json
├── native-properties.json
└── diagnostics.json
```

---

## 3. manifest.json

必填：

```json
{
  "schema_version": "1.0.0",
  "scene_id": "SCENE_001",
  "workspace_id": "WS_001",
  "canvas_id": "POU_MAIN",
  "beh_jar_sha256": "...",
  "entry_xml_sha256": "...",
  "exporter_version": "...",
  "coordinate_space": "BEH_WORLD",
  "generated_at": "...",
  "status": "COMPLETE"
}
```

---

## 4. scene.svg

要求：

- 完整可显示；
- `viewBox` 正确；
- 不依赖外部网络资源；
- 关键对象附 ID 或可通过 sidecar 稳定映射；
- 字体和资源缺失写 diagnostics；
- 禁止内嵌脚本。

推荐：

```xml
<g data-native-id="N17" data-kind="node">...</g>
<path data-native-id="R8" data-kind="relation">...</path>
```

---

## 5. scene.json

顶层：

```json
{
  "schema_version": "1.0.0",
  "scene_id": "SCENE_001",
  "bounds": {},
  "nodes": [],
  "ports": [],
  "relations": [],
  "labels": [],
  "groups": []
}
```

### Node

```json
{
  "native_id": "N17",
  "native_type": "...",
  "display_name": "+",
  "internal_name": "test-3",
  "bounds": {"x":0,"y":0,"width":40,"height":30},
  "z_index": 1,
  "property_ref": "PROP_N17"
}
```

### Port

```json
{
  "native_id": "P17",
  "owner_node_id": "N17",
  "direction": "OUT",
  "position": {"x":40,"y":15},
  "property_ref": "PROP_P17"
}
```

### Relation

```json
{
  "native_id": "R8",
  "source_node_id": "N17",
  "source_port_id": "P17",
  "target_node_id": "N18",
  "target_port_id": "P18",
  "path_points": [],
  "arrow": {"direction":"SOURCE_TO_TARGET","position":"TARGET"},
  "property_ref": "PROP_R8"
}
```

---

## 6. hit-map.json

所有几何使用世界坐标。

Node：Bounds / Polygon。

Relation：Path + Tolerance。

```json
{
  "native_id": "R8",
  "kind": "RELATION",
  "shape": "STROKED_PATH",
  "path_points": [],
  "hit_tolerance": 6
}
```

`hit_tolerance` 仅用于交互，不改变视觉线宽。

---

## 7. native-properties.json

只保存结构化属性，不强迫 Web 解析任意 Java 对象。

```json
{
  "PROP_R8": {
    "native_id": "R8",
    "kind": "RELATION",
    "properties": {}
  }
}
```

---

## 8. diagnostics.json

```json
{
  "errors": [],
  "warnings": [],
  "unknown_objects": [],
  "unrendered_objects": [],
  "missing_resources": [],
  "timings": {},
  "counts": {}
}
```

---

## 9. 完整性约束

- 所有 Node ID 唯一；
- 所有 Relation ID 唯一；
- Relation端点存在，或明确为 unresolved；
- hit-map ID 必须存在于 scene；
- SVG映射覆盖正式可交互对象；
- 无法导出的对象不得静默消失。

---

## 10. 版本策略

- 破坏性变更升级 major；
- 新增可选字段升级 minor；
- 修正文档不改变版本；
- Web 必须拒绝不兼容 major。
