# DeepSeek V4 Flash、GLM 5.2 与 DeepSeek Harness 工程规范

## 1. 基本假设

主模型按文本模型使用：

- 不依赖图像输入；
- 不依赖它直接理解完整复杂画布；
- 不依赖它记住大 XML 或整个代码仓；
- 不依赖未验证的高级 Agent 特性。

---

## 2. 能力探测优先

公司环境的具体模型能力必须通过 Probe 确认：

- Tool Calls；
- Structured JSON；
- Streaming；
- Parallel Tools；
- Context；
- Thinking；
- Cancellation；
- Image Input。

文档不得用“新版/旧版”描述能力，应以探测结果为准。

---

## 3. 模型职责

### 负责

- 读结构化任务；
- 规划工具查询；
- 解释图源；
- 归纳数据流；
- 生成Proposal；
- 生成候选Patch；
- 标记UNKNOWN。

### 不负责

- 精确ID比较；
- Hit Test；
- 图算法；
- 大文件索引；
- 自动生成原生内部ID；
- 直接Apply。

---

## 4. Harness定位

Harness 是可替换 Agent Runtime 和插件外壳。

业务核心仍是：

- Contracts；
- Scene Service；
- Code Intelligence；
- Task Store；
- Analysis Gateway。

Harness 迭代时不得迫使业务契约改写。

---

## 5. Tool设计

工具必须窄、类型明确、输出Canonical JSON。

推荐：

```text
beh_get_selection
beh_get_node
beh_get_relation
beh_get_boundary
beh_get_native_properties
code_find_symbol
code_find_references
code_get_context
code_find_callers
code_trace_data_flow
result_write
```

禁止大杂烩工具：

```text
analyze_everything_and_fix_project
```

---

## 6. 状态机

Explain：

```text
VALIDATE_TASK
→ READ_SELECTION
→ READ_BOUNDARY
→ QUERY_PROPERTIES
→ QUERY_CODE
→ BUILD_STEPS
→ VALIDATE_RESULT
→ WRITE_RESULT
```

Develop：

```text
VALIDATE_INTENT
→ READ_CONTEXT
→ PROPOSE_GRAPH
→ PROPOSE_CODE
→ VALIDATE
→ WRITE_PROPOSAL
```

---

## 7. 小视觉模型

MVP不依赖视觉模型。

后期只用于：

- 复杂自由草图；
- 潦草箭头；
- 用户画的非结构化布局提示。

视觉输出必须结构化，并标置信度；不能直接成为正式Graph。

---

## 8. 上下文策略

模型只获得当前任务所需局部：

- Selection；
- Boundary；
- 必要属性；
- 工具查询结果；
- 用户意图。

不把整个几十 MB XML和整个代码仓一次性塞入上下文。

---

## 9. JSON策略

- 所有输出先 Schema Validate；
- 失败允许有限修复重试；
- 超过重试转为FAILED；
- 不从自由散文中解析ID。

---

## 10. 失败预算

每个任务设置：

```text
max_steps
max_tool_errors
max_schema_repairs
timeout
```

避免模型无限循环。

---

## 11. 模型可替换

同一 Skill 契约支持 DeepSeek V4 Flash / GLM 5.2。

模型差异封装在 Provider Adapter，不进入业务 JSON。

---

## 12. 审计

记录：

- model id；
- capability profile；
- skill version；
- prompt version；
- tool calls；
- outputs；
- errors；
- token / latency（若可得）。
