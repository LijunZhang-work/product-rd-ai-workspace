# Analysis Gateway 与 DeepSeek Harness 集成预留

## 1. 目的

当前工具与 AI 分开运行，但现在就定义稳定边界，使后续一体化不需要重写 Web 或任务契约。

---

## 2. 稳定业务接口

```ts
interface AnalysisGateway {
  submit(request: AnalysisRequestRef): Promise<TaskHandle>
  getStatus(taskId: string): Promise<TaskStatus>
  getResult(taskId: string): Promise<AnalysisResultRef | null>
  cancel(taskId: string): Promise<void>
}
```

---

## 3. 当前 Adapter

```text
FileBundleAdapter
```

行为：

- 写 `tasks/TASK/input`；
- 等待外部执行；
- 观察 `output/result.json`；
- 校验并导入。

---

## 4. 后续 Adapter

```text
DeepSeekHarnessAdapter
```

可能通过：

- JSON-RPC stdio；
- 本地进程；
- Harness Tool / Plugin；
- 本地服务。

具体传输不得侵入业务契约。

---

## 5. Harness工具映射

```text
Scene Service
→ beh_get_scene / node / relation / properties

Code Intelligence
→ code_find_symbol / reference / callers / context

Task Store
→ task_read / result_write
```

---

## 6. 事件

```text
TASK_CREATED
TASK_ACCEPTED
TASK_RUNNING
TOOL_PROGRESS
TASK_COMPLETED
TASK_FAILED
TASK_CANCELLED
```

Web只显示事件，不解析模型内部思维。

---

## 7. 安全

- Explain只读；
- Develop写入独立临时环境；
- Harness无权直接改正式工作区；
- 所有写工具经过权限门；
- Web不保存API Key；
- 任务与结果有Hash和审计。

---

## 8. 兼容性

Harness处于快速迭代阶段时：

- 锁版本；
- Adapter测试；
- 契约测试；
- 升级回归；
- 保留File Adapter作为故障兜底。

---

## 9. 集成验收

同一个 Task：

```text
File Adapter Result
vs
Harness Adapter Result
```

均必须通过同一 Result Schema 和 Web联动测试。
