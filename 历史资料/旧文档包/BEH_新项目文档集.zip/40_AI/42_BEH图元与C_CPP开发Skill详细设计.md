# BEH 图元与 C/C++ 开发 Skill 详细设计

## 1. Skill名称

```text
beh-develop
```

## 2. 启用时机

只有 Explain 与 Code Binding 达到质量门槛后启用。

---

## 3. 输入

```text
DEVELOP Task Bundle
现有Scene
Selection / Target Region
Annotations
用户需求
Code Intelligence Tools
Verified Component Registry
```

---

## 4. 输出

```text
Proposal Graph Operations
Code Patch
Impact Report
Validation Plan
Uncertainties
```

不直接Apply。

---

## 5. 设计流程

### 5.1 复述目标

生成结构化 Goal，防止误解。

### 5.2 检查现有结构

- 已有节点；
- 可复用组件；
- Port；
- 圈外影响；
- 代码入口。

### 5.3 生成最小方案

优先最小修改，不为“看起来完整”增加无关组件。

### 5.4 Proposal Graph

使用 Canonical Operations。

### 5.5 Proposal Code

生成最小 Diff。

### 5.6 Validation Plan

包括：

- Graph规则；
- Build；
- Unit；
- Integration；
- Playwright（UI变化时）；
- Round-trip。

---

## 6. Verified Component Registry

AI只允许自动选择已验证组件进入低风险Proposal。

未验证组件：

```text
NEEDS_HUMAN_DESIGN
```

---

## 7. 位置与手绘

- Target Region约束位置；
- Structured Arrow表达期望流向；
- 自由草图只是Hint；
- 最终布局由规则 / 原生能力决定；
- 不因草图形状生成未经验证的正式节点。

---

## 8. 代码原则

- 不大范围重构，除非用户明确要求；
- 使用真实编译配置；
- 保持项目风格；
- 添加必要测试；
- 不修改无关文件；
- 不隐藏编译错误；
- 记录未能运行的测试。

---

## 9. Review输出

必须给人看：

```text
为什么要改
图上改什么
代码改什么
圈外影响
风险
测试
UNKNOWN
```

---

## 10. Apply与Rollback

Apply由独立执行器完成，不由模型文本完成。

使用临时工作树 / 分支，失败自动回滚。

---

## 11. Eval

覆盖：

- 新增简单延时；
- 修改参数；
- 插入节点；
- 删除连接；
- 代码同步；
- 不允许组件；
- 编译失败；
- Round-trip不一致。
