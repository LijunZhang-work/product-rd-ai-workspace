# BEH 图源解释 Skill 详细设计

## 1. Skill名称

```text
beh-explain
```

## 2. 目标

针对一个 Analysis Task，生成可定位、可举证、可切换专业/小白表达的图源解释。

---

## 3. 输入检查

- Schema版本；
- Scene Hash；
- Selection非空；
- selected IDs存在；
- Boundary可解析；
- Workspace只读；
- requested outputs受支持。

失败则写 diagnostics，不继续猜。

---

## 4. 分析顺序

### Step A：场景边界

先明确：

- 圈内对象；
- 内部关系；
- 入边；
- 出边；
- continuation / implicit。

### Step B：输入候选

从 incoming boundary 与无入边节点识别输入。

### Step C：拓扑排序 / 路径

对有向图进行确定性排序；存在环时明确标记 Cycle，不强行线性化。

### Step D：逐元素解释

每个元素：

```text
输入
操作
参数
输出
下一跳
```

### Step E：代码证据

按需调用工具，不扫描无关文件。

### Step F：两种文风

从同一结构事实生成 Professional / Beginner。

---

## 5. 代码工具调用策略

优先：

1. Direct Binding；
2. Symbol；
3. References；
4. Callers/Callees；
5. Data Flow；
6. Text Search兜底。

每个结果记录 Precision。

---

## 6. 环与分支

### 分支

分别列：

```text
条件
路径A
路径B
汇合点
```

### 环

说明：

- 反馈起点；
- 环内对象；
- 退出条件；
- 是否能静态证明。

---

## 7. Beginner版原则

- 先给直觉；
- 再给原词；
- 类比不替代真实名称；
- 不把软件控制说成物理因果；
- 关键阈值和延时保留；
- 不隐藏不确定性。

---

## 8. 证据要求

重要Claim至少一个 Evidence。

直接事实优先，AI推理最低。

---

## 9. 禁止输出

- 无ID的“左边那个块”；
- 无证据的代码文件；
- 将相邻节点说成已连接；
- 将圈外关系遗漏；
- 将HYPOTHESIS写成FACT；
- 与专业版事实不一致的小白版。

---

## 10. 输出

严格遵守 AnalysisResult Contract。

同时生成 `report.md`，但 Web以 `result.json` 为联动真值。

---

## 11. Eval

每次 Skill 或 Prompt 改动运行固定 Case；任何关键回归不得发布。
