# BEH AI 图源与代码分析工作台：项目入口与执行顺序

## 1. 项目名称与一句话定义

工作名称：

> **BEH AI 图源与代码分析工作台**

一句话定义：

> 使用 BEH 原始 JRE + JAR 在 Headless 环境生成唯一权威的原生场景；本地 Web 工作台负责人圈选、手绘、任务准备和结果联动；外部 AI Skill 结合图源、整个代码仓以及 C/C++ 证据完成解释，后续再扩展为可审查的图元与代码开发能力。

---

## 2. 已确定的开发顺序

本项目严格遵守以下顺序：

```text
先完成 AI 解释图源
        ↓
再完成 AI 开发 / 修改图元与 C/C++
```

同时严格遵守：

```text
先完成 MVP 闭环
        ↓
再补强准确性、规模和自动化
        ↓
最后进行视觉与高级交互精雕
```

禁止在 MVP 未通过时，把主要开发时间消耗在：

- 视觉细节；
- 动画；
- 高级自动布局；
- 完整 Compose 体验；
- 多模型复杂编排；
- 大而全的设置中心；
- 全工程一次性分析；
- 原生 BEH 自动写入。

---

## 3. 当前主架构

```text
BEH 原始 JRE + JAR
        │
        ▼
Headless Native Scene Service
        │
        ├─ scene.svg
        ├─ scene.json
        ├─ hit-map.json
        ├─ native-properties.json
        └─ diagnostics.json
        │
        ▼
本地 Web 工作台
        │
        ├─ 浏览原生画布
        ├─ 矩形 / 椭圆 / Lasso 圈选
        ├─ 结构化标注 / 自由笔
        ├─ 导出分析任务包
        └─ 读取并联动展示分析结果
        │
        ▼
外部 AI Skill / DeepSeek Harness
        │
        ├─ 查询场景
        ├─ 查询整个代码仓
        ├─ 分析数据流
        ├─ 输出专业版 / 小白版解释
        └─ 后续输出 Proposal Graph Operations / C++ Patch
```

Web MVP **不直接调用任何模型 API**。Web 右侧区域名称应是：

```text
分析任务
分析结果
证据
代码关联
```

不得命名为：

```text
AI聊天
问AI
AI助手
```

以免误导用户认为 Web 内置了模型调用。

---

## 4. 文档阅读顺序

### 开始任何开发前必须阅读

1. `01_PROJECT_INSTRUCTIONS_开发模型必须遵守.md`
2. `02_已验证事实_信任边界与技术决策.md`
3. `01_Current/03_项目章程_目标范围与非目标.md`
4. `01_Current/07_安全隐私权限与审计设计.md`
5. `01_Current/04_总体软件架构与目录架构.md`
6. `10_Phases/09_阶段0_项目骨架契约与测试基线.md`
7. `10_Phases/10_阶段总路线图_MVP优先.md`
8. `30_Testing/30_测试总策略_质量门禁与完成定义.md`
9. `30_Testing/35_阶段测试矩阵与发布检查表.md`

### 做 Web 前阅读

- `01_Current/05_Web工作台信息架构与交互设计.md`
- `20_Contracts/20_NativeSceneBundle_契约.md`
- `20_Contracts/21_Selection_Annotation_AnalysisTaskBundle_契约.md`
- `30_Testing/31_Playwright_Web_E2E测试规范.md`

### 做 AI 解释前阅读

- `10_Phases/13_阶段3_AI解释Skill_MVP.md`
- `20_Contracts/22_AnalysisResult_证据与联动契约.md`
- `40_AI/40_DeepSeekV4Flash_GLM52_Harness工程规范.md`
- `40_AI/41_BEH图源解释Skill详细设计.md`
- `30_Testing/33_AI_Skill评测与回归测试.md`

### 做 AI 开发图元 / C++ 前阅读

- `10_Phases/15_阶段5_AI开发图元与C_CPP.md`
- `20_Contracts/23_ProposalGraphOperations_CodePatch契约.md`
- `40_AI/42_BEH图元与C_CPP开发Skill详细设计.md`

### 只有 MVP 通过后再阅读

- `90_Polish/90_UI视觉精雕与高级交互规划.md`
- `90_Polish/91_SemanticView与教学可视化增强规划.md`
- `90_Polish/92_规模化性能与部署优化规划.md`

---

## 5. 当前最先执行的里程碑

按顺序执行：

```text
阶段 0：项目骨架、契约与测试基线
阶段 1：Headless Native Scene MVP
阶段 2：Web 查看、圈选、标注与任务包导出 MVP
阶段 3：外部 AI 解释 Skill MVP
阶段 4：代码仓关联与数据流增强
阶段 5：AI 开发图元与 C/C++ Proposal
阶段 6：Workbench 与 Harness 一体化
```

任何阶段存在关键 FAIL，不得进入下一阶段。

---

## 6. 完成声明的最低要求

任何 UI 或工作流功能，以下说法均不能证明完成：

```text
代码已经写完
build 已通过
typecheck 已通过
单元测试通过
文件已经创建
```

必须有：

- 实际运行；
- 可复现输入；
- 自动测试；
- Playwright 或对应服务测试证据；
- 截图 / Trace / 结构化结果；
- PASS / FAIL 验收表；
- 未测试项和剩余风险。

---

## 7. 最高事实源顺序

```text
原始 JAR 实际运行结果
>
原始 XML 与原生场景输出
>
固定程序生成的可复现证据
>
自动测试与 Golden Fixture
>
AI 推理
>
未经独立验证的人的猜测
```

人的明确观察可以作为测试真值，例如：

> “原生 BEH 里这个图元只有一根输出线。”

但不能直接硬编码成：

```text
这个节点永远只保留一条线
```

程序必须证明多出来的关系为什么被产生，以及为什么应被拒绝。
