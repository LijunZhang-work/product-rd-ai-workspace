# 阶段总路线图：MVP 优先，解释先于开发

## 1. 总顺序

```text
阶段 0：项目骨架与契约门禁
阶段 1：Headless Native Scene MVP
阶段 2：Web 查看、圈选、标注与导出 MVP
阶段 3：AI 解释 Skill MVP
阶段 4：代码仓关联与数据流增强
阶段 5：AI 开发图元与 C/C++ Proposal
阶段 6：Workbench 与 DeepSeek Harness 一体化
阶段 7：视觉精雕、Semantic View 与规模优化
```

阶段 7 内容排在最后，不阻塞前六阶段。

---

## 2. 阶段 0：项目骨架与契约

目标：

- Monorepo；
- JSON Schema；
- Fixture；
- CI；
- 基础日志；
- 统一错误码；
- 模型能力探测；
- Playwright 骨架。

完成门槛：

- 契约测试可运行；
- Web 空壳能运行；
- Java 服务健康检查可运行；
- CI 能阻止空白 UI 被声明完成。

---

## 3. 阶段 1：Headless Native Scene MVP

只完成：

- 打开一个工作区；
- 列出 POU；
- 生成一个完整场景；
- Node / Port / Relation / Arrow / Label 带 native ID；
- 导出 Bundle；
- Golden Test。

不做：

- Web手绘；
- AI；
- 代码索引；
- 高级缓存。

---

## 4. 阶段 2：Web 查看与任务准备 MVP

只完成：

- 加载 Scene Bundle；
- 浏览 / Zoom / Pan；
- 点选；
- 矩形 / 椭圆 / Lasso；
- 结构化 Arrow / Text Note；
- 自由笔原样保存；
- 生成 Selection；
- 导出 Analysis Task Bundle；
- 右、下可折叠；
- Playwright 通过。

不做：

- AI结果生成；
- 完整自由笔理解；
- Proposal。

---

## 5. 阶段 3：AI 解释 Skill MVP

只完成：

- 外部 Skill 读取 Task Bundle；
- 查询当前场景和必要代码；
- 输出 Professional / Beginner；
- 按步骤输出数据流；
- 每步附 focus_refs 与 evidence_refs；
- Web 导入 Result Bundle；
- 点击步骤联动画布。

不做：

- 改图；
- 改代码；
- 自动 Apply。

---

## 6. 阶段 4：代码关联增强

完成：

- compile_commands；
- clangd索引；
- Symbol / Reference / Call Graph；
- Scene-to-Code Binding；
- 边界调用；
- 局部数据流；
- 解释结果联动代码。

---

## 7. 阶段 5：AI 开发 Proposal

完成：

- Target Region；
- 文字诉求；
- 结构化 Annotation；
- 可选自由草图；
- Proposal Graph Operations；
- C/C++ Diff；
- Review；
- 编译 / 测试；
- 不直接写正式工程。

---

## 8. 阶段 6：Harness 一体化

把当前：

```text
文件任务包 + 人工触发
```

升级为：

```text
Web → Analysis Gateway → Harness Adapter → Result
```

契约不变，只替换传输方式。

---

## 9. 阶段 7：精雕与规模优化

包括：

- 视觉系统；
- 动画；
- Semantic View；
- 教学播放；
- 多屏；
- 超大场景虚拟化；
- 远程索引；
- 部署优化。

进入条件：

> 解释 MVP 与开发 Proposal 的核心准确性、测试和回归已经建立。

---

## 10. 每阶段统一完成条件

```text
契约通过
单元测试通过
集成测试通过
实际运行通过
Playwright / 对应服务测试通过
关键截图 / Trace 存在
失败状态被覆盖
文档已更新
未测试项已列出
```
