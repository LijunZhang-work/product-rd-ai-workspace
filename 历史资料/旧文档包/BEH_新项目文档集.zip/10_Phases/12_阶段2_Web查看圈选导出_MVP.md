# 阶段 2：Web 查看、圈选、标注与任务包导出 MVP

## 1. 目标

建立一个不调用 AI API 的本地 Web 工作台，使用户可以：

- 配置工作区；
- 选择 POU；
- 查看原生场景；
- 点击 Node / Relation；
- 矩形、椭圆、Lasso 圈选；
- 添加结构化标注和自由笔；
- 导出 Analysis Task Bundle。

---

## 2. MVP 页面

### 工作区配置

字段：

- 代码仓根路径；
- 主入口 XML；
- BEH JRE；
- BEH JAR / Classpath；
- 可选 compile_commands。

### 主工作台

- 左：工作区 / POU 树；
- 中：原生 SVG 画布；
- 右：可折叠选择 / 任务面板；
- 下：可折叠代码抽屉占位。

---

## 3. 圈选与命中

选择过程：

```text
屏幕 Pointer
→ 逆变换到 BEH World Coordinate
→ Selection Geometry
→ HitMap intersection
→ Selected IDs
```

所有 Selection 保存世界坐标。

---

## 4. 手绘

### MVP支持

- Arrow；
- Box；
- Text Note；
- Freehand Stroke。

### 语义规则

- Arrow / Box / Text 是结构化 Annotation；
- Freehand 默认 unresolved；
- 不调用视觉模型；
- 用户文字优先解释意图。

---

## 5. 任务包

导出内容见：

`20_Contracts/21_Selection_Annotation_AnalysisTaskBundle_契约.md`

导出前必须 Schema Validate。

---

## 6. 右侧和底部面板

必须：

- 展开 / 折叠；
- 拖动尺寸；
- 记住状态；
- 一键纯画布；
- 折叠不丢选择；
- 重新展开不重新加载 Scene。

---

## 7. 错误状态

禁止空白无提示。

至少覆盖：

- Scene服务不可用；
- 路径无效；
- Scene生成失败；
- SVG无对象；
- HitMap缺失；
- Task Schema失败；
- 文件权限失败。

---

## 8. Playwright 必测流程

```text
打开应用
→ 创建工作区
→ 选择POU
→ Scene显示
→ 点击Node
→ 点击Relation
→ 矩形圈选
→ Lasso圈选
→ 添加Arrow与Text
→ 折叠右侧
→ 折叠底部
→ 导出任务包
→ 校验导出内容
```

详细见：

`30_Testing/31_Playwright_Web_E2E测试规范.md`

---

## 9. 本阶段不做

- 分析结果自动生成；
- 代码索引完整功能；
- AI开发；
- Proposal；
- Semantic View；
- UI高级动画。

---

## 10. 完成门槛

```text
[ ] Scene真实可见
[ ] Node/Relation可点
[ ] 三类圈选正确
[ ] Annotation可保存
[ ] 面板折叠可用
[ ] Task Bundle通过Schema
[ ] Playwright全流程通过
[ ] Console无关键错误
[ ] Trace与截图存在
```
