# 阶段 3：AI 解释 Skill MVP

## 1. 目标

在不修改图元和代码的前提下，让外部 Skill 针对一个圈选区域生成可追踪的解释。

---

## 2. 输入

```text
AnalysisTaskBundle
+
只读场景查询工具
+
只读代码仓查询工具
```

主模型按文本模型使用，不依赖图像输入。

---

## 3. 输出

```text
AnalysisResultBundle/
├── result.json
├── report.md
├── evidence-index.json
└── diagnostics.json
```

契约见：

`20_Contracts/22_AnalysisResult_证据与联动契约.md`

---

## 4. 必须回答的内容

### 4.1 概述

这块整体在干什么？

### 4.2 输入

- 从哪些圈外图元 / 端口进入；
- 输入是什么；
- 对应哪些变量 / 函数；
- 证据是什么。

### 4.3 数据流步骤

按顺序说明每个元素：

```text
接收什么
做了什么
使用什么参数
产生什么
传给哪里
```

### 4.4 输出

- 图内最终输出；
- 圈外输出；
- 对其他模块和代码状态的影响。

### 4.5 两种版本

- Professional；
- Beginner。

Beginner 可以类比，但不得替换事实。

### 4.6 不确定项

必须单列 UNKNOWN。

---

## 5. 联动引用

每个步骤必须包含：

```text
node_ids
relation_ids
port_ids
code_refs
evidence_ids
```

Web 点击步骤后，根据这些 ID 高亮，而不是从解释文字猜位置。

---

## 6. Skill 工作流

```text
validate task
↓
read selected subgraph
↓
read boundary context
↓
identify inputs / outputs
↓
query native properties
↓
query relevant code only
↓
build ordered steps
↓
write evidence-linked result
↓
validate result schema
```

---

## 7. 模型行为限制

禁止：

- 修改文件；
- 生成正式 Graph Operation；
- 把相邻图元当作连接；
- 无证据声称代码绑定；
- 遗漏明显 boundary；
- 只给泛泛概述而不逐步说明。

---

## 8. MVP 代码仓策略

如果代码索引尚未完成：

- 允许基于显式绑定和文本查找；
- 标记 Code Precision = DEGRADED；
- 不阻塞纯图源解释；
- 不得伪装成完整代码分析。

---

## 9. 测试

Golden Eval 至少覆盖：

- 线性输入→处理→输出；
- 分支；
- 多输入；
- boundary；
- continuation；
- 无代码绑定；
- 错误代码候选；
- UNKNOWN。

详细见：

`30_Testing/33_AI_Skill评测与回归测试.md`

---

## 10. 完成门槛

```text
[ ] 结果Schema稳定
[ ] 每个步骤有focus_refs
[ ] 每个事实有evidence
[ ] Professional/Beginner均可读
[ ] Boundary被解释
[ ] UNKNOWN不被隐藏
[ ] Web可导入并联动
[ ] Golden Eval达标
```
