# 阶段 6：Workbench 与 DeepSeek Harness 一体化

## 1. 目标

把阶段 3～5 中的人工任务传递：

```text
导出目录
→ 人在Harness中触发
→ 再把结果导回Web
```

升级为：

```text
Web
→ Analysis Gateway
→ Harness Adapter
→ Agent Session
→ Result
→ Web
```

用户不再手工搬文件。

---

## 2. 前提

当前文件任务包必须已经稳定。

一体化只替换传输和触发方式，不改变：

- Scene Contract；
- Task Contract；
- Result Contract；
- Proposal Contract。

---

## 3. Analysis Gateway

稳定接口：

```text
submit(request)
getStatus(taskId)
streamEvents(taskId)
getResult(taskId)
cancel(taskId)
```

Adapter：

```text
FileBundleAdapter    # 当前
HarnessAdapter       # 本阶段
```

---

## 4. Harness Plugin 结构

建议：

```text
beh-scene-tools
beh-code-tools
beh-analysis-skill
beh-development-skill
beh-result-writer
```

Tool 使用窄接口和 Canonical JSON 输出。

---

## 5. 兼容性边界

DeepSeek Harness 当前迭代较快，因此：

- 锁定已验证版本；
- Adapter 隔离内部 API；
- 工具契约独立；
- Session ID 不写入业务事实；
- 升级前运行完整回归。

---

## 6. 权限

Explain Agent：只读。

Develop Agent：

- Proposal 权限；
- 临时工作树；
- 受限测试命令；
- Apply 需要确认。

---

## 7. 测试

- File Adapter 与 Harness Adapter 同一任务结果兼容；
- 中断 / 重试；
- 取消；
- Harness重启；
- Result重复写入；
- Schema不兼容；
- 权限拒绝；
- 大结果 Spill；
- Session日志审计。

---

## 8. 完成门槛

```text
[ ] Web一键提交
[ ] 状态可见
[ ] 结果自动返回
[ ] 取消有效
[ ] 契约未变化
[ ] Harness升级可替换
[ ] 无需Web保存模型Key
```
