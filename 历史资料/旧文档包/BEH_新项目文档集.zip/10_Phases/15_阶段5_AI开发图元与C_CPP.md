# 阶段 5：AI 开发图元与 C/C++ Proposal

## 1. 进入条件

必须先完成：

- 稳定 Scene；
- 圈选与 Annotation；
- AI解释；
- 代码关联；
- Evidence / Review；
- 回归测试。

---

## 2. 目标

用户可以：

- 圈一个现有区域；
- 圈一块目标空白区域；
- 添加 Arrow、Box、Text；
- 可选自由草图；
- 描述需求。

AI 输出：

- Proposal Graph Operations；
- 候选 C/C++ Patch；
- 影响范围；
- 验证计划；
- 不确定项。

---

## 3. 输出不得直接生效

```text
AI输出
↓
Schema Validate
↓
Proposal Review
↓
结构校验
↓
代码校验
↓
人确认
↓
Apply
```

Web MVP 不自动 Apply。

---

## 4. Graph Operations

允许：

```text
CREATE_NODE
MOVE_NODE
SET_PARAMETER
CONNECT
DISCONNECT
DELETE_NODE
```

每个操作必须引用：

- native / proposal ID；
- 目标区域；
- 前置条件；
- 证据；
- 风险。

AI 不生成 relation_id 等原生内部 ID。

---

## 5. C/C++ Patch

必须：

- Unified Diff；
- 文件范围明确；
- 修改原因；
- 关联图元；
- 格式化；
- 编译结果；
- 测试结果；
- 回滚方式。

---

## 6. 草图处理

### 结构化 Annotation

文本模型可直接使用。

### 自由手绘

MVP开发功能中仅作为：

- 位置提示；
- 强调；
- 用户文字的辅助。

复杂图形识别后期才接小视觉模型。

---

## 7. Review

必须显示：

- 新增 / 删除 / 修改图元；
- 新增 / 删除 Relation；
- 影响圈外对象；
- 修改代码文件；
- 编译 / 测试；
- UNKNOWN；
- 是否可自动落地。

---

## 8. Native 落地顺序

优先：

```text
Native BEH Driver / 原生命令
```

必要时：

```text
Native Template + Minimal Patch
```

禁止完全重写未知私有工程。

---

## 9. Round-trip

```text
Proposal A
↓
落地
↓
BEH重新保存 / 导出
↓
重新解析 Scene B
↓
Semantic Compare A vs B
```

不一致则 BLOCK。

---

## 10. 完成门槛

```text
[ ] Proposal不污染正式工程
[ ] Graph Ops通过校验
[ ] Patch可审查
[ ] 编译/测试可运行
[ ] 影响范围清楚
[ ] 人工确认有效
[ ] Round-trip有结果
```
