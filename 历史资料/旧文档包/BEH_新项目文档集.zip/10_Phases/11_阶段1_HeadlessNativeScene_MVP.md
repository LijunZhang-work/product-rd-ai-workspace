# 阶段 1：Headless Native Scene MVP

## 1. 目标

用原始 BEH JRE + JAR 对一个真实小 POU 生成可查询、可显示、可回归的完整场景包。

---

## 2. 输入

```text
BEH JRE路径
BEH JAR/ClassPath
主入口XML
Canvas / POU ID
```

---

## 3. 输出

```text
NativeSceneBundle/
├── manifest.json
├── scene.svg
├── scene.json
├── hit-map.json
├── native-properties.json
└── diagnostics.json
```

契约见：

`20_Contracts/20_NativeSceneBundle_契约.md`

---

## 4. MVP 支持范围

必须支持：

- Node；
- Display Text；
- Port；
- Relation ID；
- Source / Target；
- Relation Path；
- Arrow；
- Label；
- Native ID；
- Bounds / Hit Shape；
- Diagnostics。

---

## 5. JCanvas 处理

明确：

- 不实例化 JCanvas；
- 不调用原生 JCanvas 选择；
- 不依赖 GUI Hit Test；
- Scene Service 只产生场景和几何；
- Web 以后自行交互。

---

## 6. 服务接口

```text
GET /health
POST /workspaces/open
GET /workspaces/{id}/canvases
POST /workspaces/{id}/scenes/{canvasId}/render
GET /jobs/{jobId}
DELETE /jobs/{jobId}
GET /scenes/{sceneId}/bundle
```

所有长任务返回 Job ID，可查询、可取消。

---

## 7. 准确性要求

同一 Fixture 的：

- Node 数量；
- Port 数量；
- Relation 数量；
- Native ID；
- Display Text；
- Source / Target；
- Arrow；
- Path；

与人工确认真值完全一致。

任何未知对象写入 diagnostics，不得静默忽略。

---

## 8. 性能基础

MVP 即要求：

- 不把所有 POU 一次渲染；
- 先列画布元数据；
- 按需渲染当前画布；
- 支持取消；
- 日志包含阶段耗时；
- 有内存峰值记录；
- 输出可缓存。

高级虚拟化后置。

---

## 9. 测试

必须包含：

### Unit

- manifest；
- ID映射；
- SVG合法性；
- HitMap几何；
- Diagnostics。

### Golden Fixture

至少：

1. 单线 A→B；
2. 一对多；
3. 多入一出；
4. continuation；
5. 特殊箭头；
6. 相邻但不相连。

### Integration

独立 Java 进程加载 JRE / JAR，真实输出 Bundle。

### Determinism

规范化后重复运行输出一致。

详细见：

`30_Testing/32_JavaHeadless服务测试与GoldenFixture.md`

---

## 10. 完成门槛

```text
[ ] 真实小POU Full Scene导出
[ ] 所有正式对象带Native ID
[ ] HitMap可供Web使用
[ ] 不依赖JCanvas
[ ] Golden测试通过
[ ] 失败有Diagnostics
[ ] 性能基线已记录
```

未全部通过，不进入阶段 2。
