# AI Skill 评测与回归测试

## 1. 目标

评估 DeepSeek V4 Flash、GLM 5.2 或其他模型在本项目 Skill 和工具条件下的真实能力，而不是凭主观感觉。

---

## 2. 模型能力探测

每个 Provider 先运行 Capability Probe：

```json
{
  "tool_calls": true,
  "structured_json": true,
  "parallel_tools": false,
  "image_input": false,
  "max_context_verified": 0,
  "streaming": true,
  "cancellation": true
}
```

只使用已验证能力。

---

## 3. Explain Eval 数据集

每个 Case 包含：

- Task Bundle；
- 预期关键事实；
- 允许措辞变化；
- 禁止结论；
- 预期 focus refs；
- 预期 boundary；
- 预期 UNKNOWN。

---

## 4. Explain 指标

### Structural Accuracy

- 输入识别；
- 步骤顺序；
- 输出识别；
- Boundary；
- Node / Relation引用。

### Evidence Accuracy

- Evidence支持对应Claim；
- 不引用无关代码；
- 不伪造ID。

### Code Accuracy

- 文件 / 行号；
- Symbol；
- 调用方向；
- Precision标记。

### Beginner Fidelity

小白版不得改变事实。

### Uncertainty Honesty

无法证明时必须UNKNOWN。

---

## 5. 典型失败

- 只复述标签；
- 忽略圈外联系；
- 把空间邻近当关系；
- 把 Relation 方向反转；
- 代码符号同名误绑；
- 小白版过度类比；
- Evidence与结论不匹配；
- 输出JSON不合法。

---

## 6. Develop Eval

后期评估：

- 是否只输出Proposal；
- Graph Ops合法；
- 不生成内部relation_id；
- Patch可应用；
- Build/Test通过；
- 影响范围；
- 不破坏现有逻辑；
- Round-trip。

---

## 7. 模型对比

同一固定工具、Prompt和Fixture比较：

```text
DeepSeek V4 Flash
GLM 5.2
```

记录：

- 成功率；
- Tool Call错误；
- JSON修复次数；
- Token；
- 延迟；
- UNKNOWN率；
- 幻觉率。

不得因为模型名称预设胜负。

---

## 8. Prompt / Skill版本

```text
BEH_EXPLAIN_SKILL_V1
BEH_DEVELOP_SKILL_V1
```

每次变化运行全量回归。

---

## 9. 门槛

MVP不要求文风完美，先要求：

- 关键事实准确；
- Evidence可追；
- Schema稳定；
- UNKNOWN诚实；
- Web可联动。
