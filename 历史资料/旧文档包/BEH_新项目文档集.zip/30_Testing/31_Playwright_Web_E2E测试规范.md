# Playwright Web E2E 测试规范

## 1. 适用范围

Playwright 测试本地 Web 工作台。

它不用于直接自动化普通 Java 桌面 GUI。

---

## 2. 基本配置

建议：

- TypeScript；
- Chromium为主；
- Firefox/WebKit做周期性兼容测试；
- 固定 Viewport；
- `trace: on-first-retry`；
- 失败截图和视频；
- 禁用动画；
- Fixture Scene；
- `data-testid` 和 `data-native-id`。

---

## 3. 必测健康项

每个主流程先检查：

1. URL / Title正确；
2. 页面非空白；
3. 无框架错误 Overlay；
4. Console无关键Error；
5. Scene根SVG存在；
6. Node / Relation数量符合Fixture；
7. 画布尺寸非0；
8. 工具栏可点击。

---

## 4. 阶段2主流程

```text
打开应用
→ 创建工作区
→ 加载POU
→ Scene显示
→ 点击Node
→ 点击Relation
→ 矩形选择
→ 椭圆选择
→ Lasso选择
→ Arrow标注
→ Text标注
→ Freehand保存
→ 折叠右侧
→ 展开右侧
→ 折叠底部
→ 纯画布模式
→ 导出任务包
```

每个动作后必须检查状态变化。

---

## 5. 选择测试

### Node

验证 selected ID。

### Relation

验证细线扩大 Hit Tolerance 后可选，且不会选中旁边 Relation。

### Lasso

验证世界坐标、Zoom后选择一致。

### Boundary

验证选择包中：

- internal；
- incoming；
- outgoing。

---

## 6. 面板测试

验证：

- 折叠后画布扩大；
- 世界坐标不变；
- Zoom/Pan不丢；
- 选择不丢；
- 尺寸持久化；
- 键盘可操作。

---

## 7. 导出测试

拦截或读取下载文件：

- 文件存在；
- JSON Schema通过；
- selected IDs正确；
- Annotation正确；
- Preview不是唯一真值；
- Hash和版本存在。

---

## 8. 分析结果测试

阶段3加入：

```text
导入固定Result
→ 显示专业版
→ 切换小白版
→ 点击Step
→ 高亮Node/Relation
→ 打开代码抽屉
→ 定位代码行
```

---

## 9. Proposal测试

阶段5加入：

- Proposal可见；
- 正式图不被修改；
- Review列表正确；
- Reject恢复；
- Accept前有确认；
- Diff可查看。

---

## 10. 视觉回归

只为稳定状态建基线：

- Scene首次加载；
- 选中；
- 面板折叠；
- Analysis Step聚焦；
- Proposal。

不要对动态进度和时间戳做像素基线。

固定 OS / Browser / Font。

---

## 11. 大场景测试

检查：

- 首屏不空白；
- 页面仍响应；
- 拖动 / Zoom可用；
- 选择工作不阻塞；
- 面板操作不卡死；
- 长任务可取消。

---

## 12. 调试产物

失败时保留：

```text
trace.zip
screenshot.png
console.json
network.har（必要时）
exported-task/
```

---

## 13. 禁止完成声明的情况

- 只跑 build；
- 只跑单测；
- 页面实际空白；
- 按钮无handler；
- Console有初始化异常；
- 关键E2E被skip；
- 截图与状态不符。
