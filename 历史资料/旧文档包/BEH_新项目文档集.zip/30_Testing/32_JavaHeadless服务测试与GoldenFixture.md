# Java Headless Scene Service 测试与 Golden Fixture

## 1. 目标

证明原始 JRE + JAR 在 Headless 模式下输出的场景准确、稳定、可重复。

---

## 2. Fixture 分类

### M01 单线

```text
A.OUT → B.IN
```

### M02 分叉

```text
A → B
A → C
```

### M03 汇合

```text
A → C
B → C
```

### M04 Continuation

验证显示和隐式关系。

### M05 相邻不连接

防止坐标误连。

### M06 重叠/交叉线

验证 Relation ID 和 Path。

### M07 无效输入

坏XML、缺资源、缺属性。

### M08 大 POU

性能基线。

---

## 3. Golden 内容

不要只存截图。

存：

```text
expected-scene.json
expected-hit-map.json
expected-diagnostics.json
expected-scene.svg（规范化）
```

---

## 4. 结构断言

- ID唯一；
- 数量；
- Source/Target；
- Port；
- Arrow；
- Path；
- Display Name；
- Bounds；
- Diagnostics。

---

## 5. SVG规范化

在比较前处理：

- 非语义属性排序；
- 浮点精度；
- 随机ID；
- 时间戳；
- 无关属性顺序。

但不得删除：

- Native ID；
- Path；
- Arrow；
- Text；
- Geometry。

---

## 6. Headless真实性

测试进程：

- 不启动GUI；
- 可设置 `java.awt.headless=true` 时记录；
- JCanvas不实例化；
- 失败依赖明确报告。

---

## 7. 原始JAR Hash

每次测试记录：

```text
JRE version
JAR hash
Exporter version
Fixture hash
```

JAR变更触发全量Golden回归。

---

## 8. 错误测试

- JAR不存在；
- JRE不兼容；
- ClassPath错误；
- XML权限；
- 资源缺失；
- 超时；
- 取消；
- 输出目录不可写。

---

## 9. 性能指标

记录：

- Parse time；
- Scene build time；
- SVG export time；
- Peak memory；
- Object counts；
- Output size。

---

## 10. 完成门槛

Golden Fixture全通过，且无静默丢对象。
