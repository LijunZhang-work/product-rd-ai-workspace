# Semantic View 与教学可视化增强规划

## 1. 目的

Original View 保持原生 BEH 结构。

Semantic View 用于：

- 减少交叉；
- 按输入—处理—输出整理；
- 小白教学；
- 数据流播放；
- 跨簇摘要。

---

## 2. 非权威属性

Semantic View 是派生视图，不是正式 BEH 画布。

它必须保留：

```text
native node id
native relation id
source/target
```

不得反过来覆盖 Original View。

---

## 3. 技术备选

根据需求选择：

- Sprotty；
- React Flow；
- ELK；
- 自定义 SVG。

选择依据不是Star，而是：

- Port约束；
- 布局；
- 编辑；
- 规模；
- 团队维护能力。

---

## 4. 教学增强

- Step编号；
- 数据Token沿路径播放；
- 关键参数浮层；
- Professional/Beginner同步；
- 边界关系摘要；
- 代码步骤联动；
- 静态文本替代路径。

---

## 5. 进入条件

Original View、Explain Skill和Evidence联动稳定后才开发。
