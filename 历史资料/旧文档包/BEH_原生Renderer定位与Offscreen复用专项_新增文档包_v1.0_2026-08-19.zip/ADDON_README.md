# BEH 原生 Renderer 定位与 Offscreen 复用专项包

**版本：** v1.0  
**日期：** 2026-08-19  
**性质：** 只新增，不修改已有项目文档

## 已确认新事实

当前 Workbench 的视觉是：

```text
Original JAR
→ 解析 MoML / Native Model
→ 当前项目重新生成视觉
```

而不是：

```text
Original BEH Renderer
→ Native Visual Output
```

因此现有视觉实现属于 Derived Renderer。

## 本包目的

下一步不再继续精修 Derived Renderer。

专项任务是：

```text
定位真正原生 Renderer / Painter
↓
明确 JCanvas 与绘制链边界
↓
验证 Graphics2D / Offscreen / SVGGraphics2D
↓
判断原生 Renderer 能否直接复用
```

开发模型继续当前任务前，应优先读取：

```text
20_Testing/34_BEH原生Renderer定位与Offscreen复用专项_v1.0.md
```
