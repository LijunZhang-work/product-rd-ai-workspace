# BEH 原生 Renderer 定位与 Offscreen 复用专项

**版本：** v1.0  
**日期：** 2026-08-19  
**性质：** 新增专项文档，不修改既有项目文档  
**当前已确认事实：** 当前 Workbench 的正式视觉并非来自 BEH 原生 Renderer 输出，而是从解析后的 MoML / Native Model 重新生成  
**本轮目标：** 定位真正负责 BEH 最终视觉呈现的原生 Renderer / Painter 链，并验证是否可以脱离 JCanvas 以 Headless / Offscreen 方式复用

---

# 1. 当前问题已经定性

当前实现不是：

```text
Original BEH Renderer
↓
Native Visual Output
↓
Web
```

而是：

```text
Original JAR
↓
解析 MoML / Native Model
↓
当前项目自行生成 Scene / SVG
↓
Web
```

因此当前视觉链属于：

```text
Native Model Reuse
+
Derived Rendering
```

而不是：

```text
Native Renderer Reuse
```

这两者必须严格区分。

---

# 2. 当前 Derived Renderer 的定位

现有从 MoML / Native Model 重新生成的视觉实现：

```text
不得删除
但不得继续作为 Original View 的权威视觉输出
```

建议改名为：

```text
derived-scene.svg
```

或：

```text
semantic-debug.svg
```

用途：

- Debug；
- 模型结构检查；
- Semantic View；
- AI辅助理解；
- 自动布局；
- 差异分析；
- 测试中间态。

禁止称为：

```text
native-render.svg
original-scene.svg
BEH原生视觉
```

---

# 3. 最终目标架构

目标改为：

```text
                 Original BEH JAR
                        │
                        ▼
                Native Model / MoML
                  │              │
                  │              │
                  ▼              ▼
       Structured Scene      Original Renderer
       scene.json            Painter / Figure /
       hit-map.json          Connector / Arrow /
       properties.json       Label / Graphics2D
                  │              │
                  │              ▼
                  │        Native Visual Output
                  │        SVG / PNG / Vector
                  │              │
                  └──────┬───────┘
                         ▼
                   Web Workbench
                         │
              ┌──────────┴──────────┐
              ▼                     ▼
       Native Visual Layer     Interaction Overlay
                              Selection / Lasso /
                              Annotation / Highlight
```

原则：

> **结构事实和视觉事实可以走两条不同输出链，但两者必须来自同一个原始 BEH Runtime / Native Model，并通过 Native ID 对齐。**

---

# 4. 本轮唯一任务

本轮不要继续改当前 Derived Renderer。

唯一任务：

> **找到“BEH 最终画面到底由谁画出来”的真实 Java 调用链。**

必须回答：

```text
Native Model
↓
???
↓
Figure / Shape / Port
↓
Connector / Relation
↓
Arrow
↓
Label
↓
Graphics2D / Paint
↓
Final Canvas
```

---

# 5. 绝对禁止事项

根因定位完成前禁止：

```text
继续优化 derived-scene.svg 的视觉
继续手工补 Arrow
继续调整 Port 位置
继续调整 Node 尺寸
继续调整 Relation routing
继续通过 CSS 模仿 BEH
继续把当前 Derived Renderer 叫 Native Renderer
继续 AI Explain / Compose 新功能
继续做视觉精修
```

---

# 6. 搜索策略：先追最终绘制入口

源码 / CFR Reference / Bytecode 中优先搜索以下关键词。

## 6.1 AWT / Swing / Java2D

```text
paint
paintComponent
paintChildren
Graphics
Graphics2D
draw
drawLine
drawPolyline
drawString
fill
Stroke
BasicStroke
AffineTransform
FontMetrics
BufferedImage
JComponent
JPanel
JCanvas
Canvas
```

## 6.2 Renderer / Painter 抽象

```text
Renderer
Painter
Figure
Shape
Icon
Graphical
Visual
View
Render
Paint
Draw
```

## 6.3 Relation / Edge / Connector

```text
Relation
Edge
Connector
Connection
Link
Arc
Site
Port
Terminal
Anchor
Route
Router
Path
```

## 6.4 Arrow

```text
Arrow
Arrowhead
ArrowHead
Marker
Head
Tail
Decorator
Endpoint
Direction
```

## 6.5 Graph / Scene 框架

如果代码中真实出现以下包/类型，再继续沿其调用链追踪：

```text
ptolemy
vergil
diva
graph
canvas
figure
connector
```

注意：

> 上述名称只作为候选搜索线索，只有代码中实际存在时才能作为项目事实，不得因为 MoML 就预设 BEH 一定完整使用某一具体图形框架。

---

# 7. 必须建立“最终画面调用链”

输出：

```text
01_final_render_call_chain.md
```

至少包含：

```text
入口类
入口方法
Native Model 输入
Node Renderer
Port Renderer
Relation / Connector Renderer
Arrow Renderer
Label Renderer
最终 Graphics / Graphics2D 对象
最终 Canvas / Component
```

每一步记录：

```text
class
method
input
output
caller
callee
evidence
confidence
```

---

# 8. 必须明确 JCanvas 的真实职责

当前已知：

```text
JCanvas 无法直接 Headless 实例化
```

本轮必须回答：

```text
JCanvas 是否只是容器？
JCanvas 是否负责事件？
JCanvas 是否负责 Viewport？
JCanvas 是否实际计算 Geometry？
JCanvas 是否直接创建 Renderer？
JCanvas 是否只是调用下层 Painter / Figure？
```

输出：

```text
02_jcanvas_dependency_boundary.md
```

目标：

> **证明哪些能力真的依赖 JCanvas，哪些绘制能力可以从 JCanvas 下方剥离复用。**

---

# 9. 原生 Renderer 责任矩阵

输出：

```text
03_native_renderer_responsibility_matrix.md
```

格式：

| 视觉能力 | 负责类/方法 | 是否依赖JCanvas | 是否可独立调用 | Headless可行性 | 证据 |
|---|---|---:|---:|---:|---|
| Node Shape |  |  |  |  |  |
| Node Bounds |  |  |  |  |  |
| Port |  |  |  |  |  |
| Relation Path |  |  |  |  |  |
| Arrow |  |  |  |  |  |
| Label |  |  |  |  |  |
| Font/Layout |  |  |  |  |  |
| Final Paint |  |  |  |  |  |

---

# 10. Offscreen 复用路线必须逐级验证

不要一上来就做大规模重构。

按以下顺序验证。

---

## Route A：直接调用原生 Renderer

理想情况：

```text
Native Model
↓
Original Renderer
↓
Graphics2D
```

如果 Renderer 方法可以直接传入 `Graphics2D`：

```java
paint(Graphics2D g)
```

或同类接口，则优先尝试：

```text
BufferedImage.createGraphics()
```

验证：

```text
不启动 GUI
↓
创建 Offscreen Graphics2D
↓
调用原 Renderer
↓
输出 PNG
```

成功标准：

```text
Node
Port
Relation
Arrow
Label
```

全部出现。

---

## Route B：Offscreen Component

如果 Renderer 强依赖某个 Swing Component，但不要求窗口真正显示：

```text
创建 Offscreen Component
↓
设置 size / model
↓
不 show()
↓
paint(offscreenGraphics)
```

验证是否可以：

```text
java.awt.headless=true
```

运行。

如果不能，则记录：

```text
HEADLESS_COMPONENT_BLOCKED
```

并继续分析依赖点。

---

## Route C：虚拟图形环境 / 非显示窗口

只有 A/B 失败后再考虑。

目标仍然是：

> 不让用户看到 GUI，但允许原生绘制链运行。

禁止在未证明必要前引入复杂虚拟桌面依赖。

---

## Route D：SVGGraphics2D / Vector Capture

如果原 Renderer 使用标准 Java2D `Graphics2D` API：

优先验证：

```text
Original Renderer
↓
SVGGraphics2D
↓
SVG
```

关键点：

> Renderer 不变，只替换绘制目标。

这与“读取模型后自己序列化 SVG”完全不同。

---

# 11. Offscreen PoC 必须使用同一个最小 POU

固定 Fixture：

```text
POC_NATIVE_RENDER_001
```

必须至少包含：

```text
2~4个Node
输入Port
输出Port
至少1条Relation
至少1个明确Arrow
至少1个Label
至少1条折线Relation（如果BEH支持）
```

不要先拿大项目。

---

# 12. Offscreen PoC 输出

至少：

```text
artifacts/
├── model_summary.json
├── derived_scene.svg
├── native_offscreen.png
├── native_offscreen.svg        # 如果SVGGraphics2D成功
├── render_trace.json
└── diagnostics.json
```

---

# 13. Renderer Reuse 判定标准

只有满足以下条件才可以称：

```text
NATIVE_RENDERER_REUSED
```

必须满足：

```text
1. Node视觉由原始BEH Renderer/Painter生成
2. Port视觉由原始BEH绘制链生成
3. Relation Path由原始BEH绘制/路由链生成
4. Arrow由原始BEH Arrow/Connector链生成
5. Label由原始BEH布局/绘制链生成
6. 当前项目没有重新计算上述正式视觉语义
```

如果只满足：

```text
原始 Parser
原始 Model
原始 IconDescription
```

则必须标记：

```text
NATIVE_MODEL_REUSED_ONLY
```

---

# 14. Arrow 是本专项的强制验证点

Arrow 是判断是否真正进入原生 Edge / Connector Renderer 的重要证据。

PoC 必须回答：

```text
Arrow对象在哪创建？
Arrow方向在哪决定？
Arrow位置在哪决定？
Arrow Shape由谁绘制？
是否属于Connector的一部分？
是否只在最终Paint阶段出现？
```

如果 Offscreen Renderer 输出：

```text
Relation存在
Arrow仍不存在
```

则不能宣称 Native Renderer 复用成功。

---

# 15. Port 是第二个强制验证点

必须回答：

```text
Port是模型对象还是View对象？
Port视觉何时创建？
Port Location从哪里来？
Port Shape由谁生成？
Port是否由Node Renderer附加？
```

如果当前 Derived Renderer 的 Port 是自己计算的：

必须在报告中明确：

```text
PORT_VISUAL_DERIVED
```

不得称为 Native Visual。

---

# 16. Relation Routing 是第三个强制验证点

必须区分：

```text
Model Topology
vs
Visual Routing
```

例如模型只告诉：

```text
A.OUT → B.IN
```

但最终 BEH 画面可能由 Renderer 决定：

```text
A.OUT
→ horizontal
→ vertical
→ horizontal
→ B.IN
```

如果当前项目自己算 `path_points`：

这属于：

```text
DERIVED_ROUTING
```

不是原生渲染复用。

---

# 17. Label / FontMetrics

必须检查：

```text
Display Text来自哪里
Label位置谁决定
字体谁决定
字号谁决定
FontMetrics谁参与
文本baseline如何确定
```

如果最终目标是接近 BEH GUI 视觉：

> FontMetrics / Label Layout 不能继续由浏览器自由猜测。

如果 Java 原 Renderer 已经完成文本布局，优先复用原始布局结果。

---

# 18. Native Visual Output 格式选择

优先级建议：

## 第一优先：SVG

如果可以通过原 Renderer + SVGGraphics2D 等直接获得。

优势：

```text
可缩放
可在Web显示
可保持vector
可绑定Native ID（需要额外映射）
```

## 第二优先：PNG / Raster

如果原 Renderer 只能稳定 Offscreen Raster：

可以先作为 MVP Native Visual Layer。

结构层仍由：

```text
scene.json + hit-map.json
```

负责点击/圈选。

不要为了坚持 SVG 又回去重写 Renderer。

---

# 19. Raster Visual + Structured HitMap 也是合法架构

如果最终得到：

```text
native-render.png
+
scene.json
+
hit-map.json
```

这仍然可以实现：

```text
Pan
Zoom
点击
矩形
Lasso
Freehand
分析高亮
```

Web 可以把 Overlay 放在 PNG 上层。

因此：

> **视觉原生复用优先级高于“必须是SVG”。**

---

# 20. Native ID 对齐

无论输出 SVG 还是 PNG，都必须保持：

```text
Native Visual
↔
scene.json
↔
hit-map.json
```

使用同一：

```text
canvas_id
render_profile
JAR hash
XML hash
model version
```

禁止视觉层和结构层来自不同版本输入。

---

# 21. Native Render 与 Derived Render 双轨保留

建议长期保留：

```text
native-render.*
derived-scene.svg
```

### native-render

用途：

```text
Original View
正式视觉
与BEH一致性
用户主画布
```

### derived-scene

用途：

```text
Semantic View
Debug
AI分析
自动布局
结构检查
```

禁止互相替代身份。

---

# 22. 本轮必须交付的报告

开发模型必须输出：

```text
01_final_render_call_chain.md
02_jcanvas_dependency_boundary.md
03_native_renderer_responsibility_matrix.md
04_offscreen_render_feasibility.md
05_graphics2d_capture_assessment.md
06_arrow_native_render_path.md
07_port_native_render_path.md
08_relation_routing_native_path.md
09_label_fontmetrics_native_path.md
10_native_renderer_reuse_conclusion.md
```

---

# 23. PoC 代码要求

PoC：

```text
必须独立
必须最小
不得大规模修改生产代码
不得先优化架构
不得顺便做UI
```

建议：

```text
poc/native-render-offscreen/
```

---

# 24. 测试要求

至少：

```text
[ ] Original JAR / Model 可加载固定POU
[ ] 原Renderer入口已定位
[ ] JCanvas依赖边界已明确
[ ] Offscreen Graphics2D PoC已尝试
[ ] Node可见
[ ] Port可见
[ ] Relation可见
[ ] Arrow可见
[ ] Label可见
[ ] Derived Renderer未被用于补偿
[ ] 结果可重复
```

---

# 25. 结果状态

只能使用：

```text
PASS
FAIL
BLOCKED
UNRESOLVED
NOT_TESTED
```

专项最终结论必须是以下之一：

```text
NATIVE_RENDERER_REUSE_FEASIBLE
NATIVE_RENDERER_REUSE_PARTIAL
NATIVE_RENDERER_REUSE_BLOCKED
NATIVE_RENDERER_REUSE_UNRESOLVED
```

---

# 26. 如果原 Renderer 可以 Offscreen 复用

下一阶段才允许设计：

```text
Native Visual Export Service
```

目标：

```text
Original JAR
↓
Native Model
↓
Original Renderer
↓
Offscreen
↓
native-render.svg/png
```

然后替换 Workbench 当前 Original View。

---

# 27. 如果原 Renderer 无法 Offscreen 复用

也不能立刻回到 Derived Renderer 精修。

必须先输出：

```text
阻塞在哪
为什么必须GUI
依赖哪些Component
是否可抽取Renderer
是否可最小修改原JAR周边Adapter
是否可在虚拟图形环境运行
```

只有这些路线都失败，才重新评估 Derived Renderer 作为正式视觉方案。

---

# 28. 最终原则

> **当前已经确认“解析 MoML 后重新生成视觉”不等于复用 BEH 原生 Renderer。**

本专项的目标不是再次理解 BEH 怎么画。

而是：

> **找到 BEH 自己真正负责画图的那条链，并尽可能让它自己画。**
