# 阶段1：大 XML Graph Engine 与 Explain MVP

## 1. 阶段目标

建立最小可用闭环：

```text
几十 MB BEH XML
↓
一次性解析 / 索引
↓
Reviewed Graph IR
↓
Original View
↓
圈选
↓
AI解释
```

目标不是一次性理解所有私有元素，而是：

> **让系统开始可查询、可审计、可解释、可逐渐收敛。**

---

## 2. 大 XML 不交给 AI

禁止：

```text
每次解释
→ 把几十MB XML交给模型
```

正确：

```text
XML
↓
Streaming Parser
↓
Persistent Graph Store
```

---

## 3. 必备索引

至少：

```text
ElementById
ParentIndex
ChildrenIndex
ForwardReferenceIndex
ReverseReferenceIndex
LocationIndex
RelationCandidateIndex
ScopeIndex
```

Graph Store 第一版可：

```text
SQLite + JSON Snapshot
```

---

## 4. Relation Family

不要假设只有一套 Relation 规律。

程序统计：

```text
Family #1
Family #2
Continuation Family
Unknown Reference Family
```

特征：

- tag；
- parent；
- attributes；
- references；
- referenced type；
- scope；
- location有无。

---

## 5. Edge Provenance

每个候选保存：

```text
candidate_edge_id
origin_xml_object
relation_id
xml_path
parser_rule
source_candidate
target_candidate
scope
evidence
```

---

## 6. Graph IR Review Gate

状态：

```text
DISCOVERED
NORMALIZED
VALIDATED
APPROVED
REJECTED
UNKNOWN
```

只有：

```text
APPROVED
```

可以 Renderer。

---

## 7. Original View

使用迁移后的统一画布：

```text
Node Geometry
= 原始_location

VisibleEdge
= Approved Edge
```

---

## 8. 圈选

支持：

```text
矩形
椭圆
Lasso
```

生成：

```text
Selection Pack
```

---

## 9. AI Explain

DeepSeek V4 Flash 只拿：

```text
Selection Pack
少量Evidence
显示名称
参数
```

输出固定结构：

```json
{
  "summary": "",
  "beginner_explanation": "",
  "professional_explanation": "",
  "inputs": [],
  "processing_steps": [],
  "outputs": [],
  "uncertainties": [],
  "evidence_refs": []
}
```

---

## 10. AI不能做

阶段1 AI禁止：

```text
决定relation是否存在
选择relation_id
静默修改Graph
扫描整个XML
```

---

## 11. 查询工具

为后续 Harness 预留：

```text
get_node
get_edge
get_neighbors
get_scope
get_edge_evidence
get_selection_pack
find_reference_paths
```

这些工具先能独立运行，再接 Agent。

---

## 12. 验收

至少用 10 个用户能人工确认的局部样本：

1. Node位置稳定；
2. Graph IR可追踪；
3. Renderer不创造Edge；
4. 圈选返回正确ID；
5. Explain基本正确；
6. 错误线可追到原始origin；
7. AI不读取整份大XML。
