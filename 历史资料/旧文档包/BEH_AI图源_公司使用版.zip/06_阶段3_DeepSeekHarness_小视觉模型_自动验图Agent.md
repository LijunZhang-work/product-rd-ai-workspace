# 阶段3：DeepSeek Harness + 小视觉模型自动验图 Agent

## 1. 阶段前提

只有固定验图工具已经稳定，才接 AI Agent。

---

## 2. 分工

```text
DeepSeek V4 Flash
= Planner

DeepSeek Harness
= Tool / Agent Orchestrator

小视觉模型
= 局部视觉定位

固定程序
= 执行、读取、精确比较
```

---

## 3. V4 Flash只做

```text
任务规划
工具选择
状态判断
有限重试
异常归纳
```

不做：

```text
大XML搜索
exact ID compare
图算法
视觉
低层鼠标实现
```

---

## 4. 小视觉模型只做

```text
局部截图定位
候选线段定位
简单弹窗确认
```

不要让它理解整个 PLC 图。

---

## 5. Harness插件建议

```text
dsh-beh-graph
dsh-beh-verify
dsh-beh-vision
dsh-beh-ui
dsh-beh-report
```

---

## 6. 工具接口

Graph：

```text
beh_get_node
beh_get_edge
beh_get_edge_evidence
beh_get_geometry
beh_get_verification_task
```

UI：

```text
beh_capture_region
beh_double_click
beh_send_keys
beh_read_clipboard
beh_read_dialog
beh_close_dialog
```

Vision：

```text
beh_vision_locate
```

---

## 7. Vision输出固定

```json
{
  "candidates": [
    {"x": 320, "y": 210, "confidence": 0.72},
    {"x": 340, "y": 235, "confidence": 0.44}
  ]
}
```

点击由固定工具执行。

---

## 8. Agent状态机

```text
LOAD_TASK
↓
GET_CONTEXT
↓
CAPTURE
↓
LOCALIZE
↓
ACTION
↓
READ_RESULT
↓
COMPARE
↓
PASS / RETRY / UNRESOLVED
```

---

## 9. 小上下文

一个任务只给：

```text
Edge ID
Source / Target
Expected relation
Geometry
最近一次结果
```

绝不把整份 XML 给 Agent。

---

## 10. 自校验依赖环境反馈

视觉点错：

```text
弹窗 actual != expected
↓
固定程序反馈
↓
Planner尝试下一候选
```

---

## 11. 失败预算

必须有：

```text
max_steps
max_retries
timeout
```

超过：

```text
UNRESOLVED
```

---

## 12. 只读权限

允许：

```text
View
Select
Double Click
Copy
Close
Zoom
Pan
```

禁止：

```text
Edit
Save
Delete
Apply
Generate
```

---

## 13. 验收

至少：

```text
20 Nodes
30 Relations
```

对照人工结果：

- PASS正确；
- MISMATCH正确；
- 点错可恢复；
- 无法确认返回UNRESOLVED；
- 不修改工程；
- 全轨迹可追踪。
