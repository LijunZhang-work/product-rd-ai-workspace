# DeepSeek V4 Flash + DeepSeek Harness + 小视觉模型：工程开发规范

## 1. 基本定位

公司环境采用：

```text
DeepSeek V4 Flash
DeepSeek Harness
小视觉模型
```

具体能力以公司环境实际测试为准。

工程不得依赖任何“假设存在但尚未验证”的模型能力。

---

## 2. DeepSeek V4 Flash定位

把它当作：

```text
文本推理器
工具调用 Planner
局部解释器
规则分析助手
```

不要把它当作：

```text
视觉模型
大XML数据库
可靠图算法引擎
精确验证器
```

---

## 3. Harness定位

Harness 用于：

```text
Agent shell
Tool registry
Plugin
Workspace
任务编排
```

业务真相不存 Harness。

---

## 4. 三角色架构

```text
V4 Flash
→ 思考 / 规划

小视觉模型
→ 看局部

固定工具
→ 查 / 算 / 点 / 比较
```

---

## 5. 推荐 Service

```text
BehGraphService
BehXmlEvidenceService
BehVisionService
BehUiAutomationService
BehVerificationService
BehProposalService
```

---

## 6. Tool必须窄

好：

```text
get_edge
get_neighbors
capture_region
double_click
read_dialog
compare_relation_id
```

坏：

```text
analyze_everything_and_fix()
```

---

## 7. Tool参数显式

优先：

```text
ID
enum
boolean
small JSON
```

少用自由文本。

---

## 8. Tool结果固定Schema

例如：

```json
{
  "result": "PASS",
  "actual_relation_id": "relation_2",
  "evidence_id": "EV22"
}
```

---

## 9. 一轮一个决定

流程：

```text
Observe
↓
Decide one action
↓
Execute
↓
Observe
```

不要一次让模型计划十几步后盲执行。

---

## 10. 强状态机

例如：

```text
READY
CONTEXT_LOADED
VISUAL_LOCALIZED
ACTION_EXECUTED
DIALOG_READ
VERIFIED
FAILED
```

---

## 11. 不用大Context补偿工具缺失

禁止：

```text
50MB XML → 模型
```

优先：

```text
Graph Query Tool
```

---

## 12. AI输出必须Schema Validation

包括：

```text
Explain
Proposal
Action Plan
Hypothesis
```

---

## 13. 事实状态

AI结论分：

```text
FACT
INFERENCE
UNKNOWN
```

---

## 14. AI不能创建 Verified Edge

AI只能提出：

```text
Candidate
```

固定 Review Engine 才能：

```text
APPROVE
```

---

## 15. 小视觉模型输入要裁剪

只看：

```text
局部
少对象
单一任务
```

例如：

```text
“找A和B之间最可能可双击的线段位置。”
```

---

## 16. 视觉输出也必须结构化

```json
{
  "candidates": [
    {"point":[123,456],"confidence":0.76}
  ]
}
```

---

## 17. 视觉不做精确文字核验

relation_id 优先：

```text
UIA / JAB
Clipboard
```

视觉读取最后兜底。

---

## 18. Exact Compare程序化

包括：

```text
relation_id
node_id
parameter value
hash
Graph operation count
```

禁止模型回答：

```text
“看起来一样。”
```

---

## 19. 失败显式结束

每任务：

```text
max_steps
max_retries
timeout
```

超过：

```text
UNRESOLVED
```

---

## 20. 关键Debug依赖Evidence

不要只给模型：

```text
一张错误图
```

而是：

```text
Edge
Origin
Scope
Reference Path
Rule
Evidence
```

---

## 21. Prompt版本化

例如：

```text
EXPLAIN_CLUSTER_SOP_V1
VERIFY_RELATION_SOP_V1
COMPOSE_GRAPH_SOP_V1
```

修改后跑回归。

---

## 22. Harness可替换

核心模块用稳定接口。

Harness Plugin只是适配层。

未来换框架，不影响：

```text
Graph Engine
Review Engine
Verification Service
```

---

## 23. 少Agent

优先：

```text
一个Main Planner
+
一组强工具
+
一个视觉Tool Provider
```

不要为了“智能”制造多个Agent互相聊天。

---

## 24. 总纲

```text
模型不记事实 → 工具查
模型不算图 → 程序算
模型不比ID → 程序比
模型不读大XML → 索引查
模型不直接改正式图 → Proposal
视觉不理解业务 → 只定位
Harness不保存真相 → Graph IR保存
```
