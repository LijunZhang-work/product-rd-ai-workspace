# Native Renderer 复用链与视觉保真专项排查

**版本：** v1.0  
**日期：** 2026-08-19  
**性质：** 新增专项排查文档，不修改既有项目文档  
**适用阶段：** 当前阶段立即执行  
**优先级：** 高于继续新增 Web 功能、AI Explain、代码关联和视觉精修

---

# 1. 本轮唯一目标

当前发现：

- 原始 BEH 工具中的同一类 POU / 图源，人眼视觉效果与当前新 Workbench 差异明显；
- 当前 Web 中还出现 Arrow 缺失；
- 不同复杂度图源的初始显示比例差异极端；
- 当前实现声称复用了 BEH 原生能力，但最终视觉结果并未达到预期的一致性。

本轮不要继续新增功能。

本轮只回答一个问题：

> **从原始 BEH 运行链到当前 Workbench，中间到底在哪一层第一次出现视觉差异？**

---

# 2. 当前禁止事项

在根因定位完成之前，禁止：

```text
直接调 CSS 让画面“更像 BEH”
直接在 Web 里补 Arrow
自己重新计算 Relation Path
自己重新计算 Port Position
自己调整 Node Geometry 迎合视觉
根据肉眼效果修改 Display Text
把 _icondescription 当成完整 Renderer
一边排查一边继续开发 AI Explain / Code Intelligence
一边排查一边继续做视觉美化
```

尤其禁止：

```text
发现箭头没有
→ Web里加 marker-end
→ 测试通过
```

如果 Arrow 原本应该来自 BEH 原生链，则必须先证明它在哪一层丢失。

---

# 3. 必须建立的五层对照链

针对同一个最小、稳定、可重复的 POU Fixture，建立以下五层输出：

```text
A. Original Native Reference
↓
B. Headless scene.json
↓
C. Headless raw scene.svg
↓
D. Minimal Raw SVG Web Embed
↓
E. Current Workbench
```

其中：

## A. Original Native Reference

优先级：

```text
1. 原始 JAR / 原生 Renderer 可重复产物
2. 已存在的原生 Golden Reference
3. 已自动化保存的原始 BEH GUI 参考输出
```

当前阶段不要求人工参与。

如果当前环境没有可自动获得的 GUI Reference，不得伪造。

可以先使用：

```text
Original JAR / Native Renderer 的确定性输出
```

作为 A 层参考，并在报告中明确：

```text
GUI_REFERENCE_NOT_AVAILABLE
```

---

## B. Headless scene.json

必须保留原始 Headless 结构输出。

重点检查：

```text
Node
Port
Relation
Arrow
Label
Display Text
Bounds
Path Points
Native ID
Style / Render Profile
```

---

## C. Headless raw scene.svg

必须是：

> Headless Native Scene Service 直接输出、未经过 Workbench 二次处理的原始 SVG。

禁止在保存 C 层之前做：

```text
前端 CSS 重写
SVG sanitizer 修改
DOM 重排
重新生成 Relation
重新生成 Marker
```

---

## D. Minimal Raw SVG Web Embed

建立一个极简测试页面：

```text
只加载 raw scene.svg
只提供必要容器
不加业务 Overlay
不加复杂 CSS
不加 Fit 策略
不加 Selection
不加 Annotation
不加 Result Panel
```

目的：

> 判断“raw SVG 本身”和“浏览器直接显示”之间是否产生差异。

---

## E. Current Workbench

当前真实 Workbench。

用于判断：

```text
Viewport
Fit
Zoom
CSS
SVG Sanitizer
Overlay
Container
Layout
```

是否破坏了原生视觉。

---

# 4. 必须比较的视觉/结构维度

每一层都至少检查：

```text
Node Shape
Node Bounds
Node Scale
Display Text
Font Family
Font Size
Font Metrics
Port Presence
Port Position
Relation Presence
Relation Path
Arrow Presence
Arrow Direction
Arrow Position
Label Presence
Label Position
Stroke Width
Stroke Style
Transform
viewBox
width / height
preserveAspectRatio
clipPath
defs
marker
z-order
overall bounds
```

---

# 5. 关键结论分类

最终结论必须明确属于以下一种或多种：

```text
A. NATIVE_RENDERER_NOT_REUSED
B. HEADLESS_EXPORTER_FIDELITY_LOSS
C. RAW_SVG_BROWSER_RENDER_DIFFERENCE
D. WEB_EMBEDDING_BREAKS_NATIVE_SVG
E. VIEWPORT_CAMERA_CAUSES_VISUAL_DISTORTION
F. MULTIPLE_CAUSES
```

不得只写：

```text
“视觉有点不一致”
```

---

# 6. 重点调查：当前到底复用了哪一层？

必须明确回答：

```text
XML Parser
Native Model
Icon Description
Port Geometry
Relation Geometry
Arrow Geometry
Label Layout
Painter / Renderer
Graphics2D
Final Canvas Composition
```

哪些来自原始 BEH，哪些是当前项目自己实现。

输出一张责任矩阵：

| 能力 | 原始 BEH 直接复用 | 当前项目重新实现 | 未确认 |
|---|---:|---:|---:|
| XML Parser |  |  |  |
| Node Model |  |  |  |
| Node Visual |  |  |  |
| Port |  |  |  |
| Relation Path |  |  |  |
| Arrow |  |  |  |
| Label |  |  |  |
| Geometry |  |  |  |
| Font/Layout |  |  |  |
| Final Renderer |  |  |  |

---

# 7. `_icondescription` 专项确认

必须回答：

> `_icondescription` 在原始 BEH 中到底承担什么职责？

至少确认：

```text
是否只负责单个图元内部视觉
是否包含 Port
是否包含 Label
是否包含 Relation Anchor
是否包含 Relation
是否包含 Arrow
是否包含最终 Bounds
是否依赖外部 Layout Context
```

禁止因为：

```text
_icondescription 能输出 SVG
```

就推出：

```text
它等于完整 BEH Renderer
```

---

# 8. JCanvas 与 Renderer 必须分开调查

当前已知：

```text
JCanvas 无法在 Headless 中直接实例化
```

但不得推出：

```text
原生 Renderer 无法 Headless 复用
```

必须分开检查：

```text
JCanvas
= GUI Container / Interaction Surface

Painter / Renderer
= Drawing Logic
```

重点搜索：

```text
paint
paintComponent
Graphics
Graphics2D
Painter
Renderer
draw
drawLine
drawPolyline
drawString
Path2D
GeneralPath
AffineTransform
Stroke
FontMetrics
```

必须回答：

```text
JCanvas 下方是否存在可独立调用的 Painter / Renderer？
是否可以使用 Offscreen Graphics2D？
是否可以使用 BufferedImage Graphics2D？
是否可以使用 SVGGraphics2D？
是否可以在不实例化 JCanvas 的情况下复用最终绘制逻辑？
```

---

# 9. Graphics2D 分支

如果原始 BEH 最终绘制链是：

```java
paint(Graphics2D g)
```

或同类结构，则优先验证：

```text
原始 Painter
↓
Offscreen Graphics2D
↓
Native Render Output
```

而不是：

```text
阅读 Painter
↓
重新写 SVG Renderer
```

目标是：

> **同一套绘制逻辑，不是第二套“理解后重写”的绘制逻辑。**

---

# 10. Arrow 专项排查

Arrow 必须严格按以下三层检查：

```text
scene.json
↓
scene.svg
↓
Web
```

## 10.1 scene.json

检查 Relation 是否包含：

```text
arrow.direction
arrow.position
```

状态可能是：

```text
SOURCE_TO_TARGET
TARGET_TO_SOURCE
BIDIRECTIONAL
NONE
UNKNOWN
```

---

## 10.2 scene.svg

检查真实 SVG 中是否存在：

```text
<marker>
<defs>
marker-start
marker-end
Arrow Path / Polygon
```

或者其他原生 Arrow primitive。

---

## 10.3 Web

如果 raw scene.svg 单独打开有 Arrow，但 Workbench 没有，排查：

```text
SVG sanitizer
<defs> 被删除
<marker> 被删除
marker id 冲突
url(#marker-id) 引用失效
CSS fill / stroke 透明
clipPath
transform
overflow
DOM ID namespace
SVG injection strategy
```

---

# 11. Arrow 禁止修法

禁止：

```text
if relation:
    marker-end = arrow
```

除非已经证明：

```text
原始 Native Scene 的同一 Relation
明确要求 target-side arrow
```

Web 不得自行决定：

```text
Direction
Position
Arrow Shape
```

---

# 12. Node / Port / Relation 分层差异报告

每个对象输出：

```json
{
  "native_id": "...",
  "object_kind": "NODE|PORT|RELATION|LABEL",
  "layer_A": {},
  "layer_B": {},
  "layer_C": {},
  "layer_D": {},
  "layer_E": {},
  "first_divergence_layer": "C",
  "difference_type": "...",
  "evidence": []
}
```

目的是：

> 精确知道“第一次不一样”在哪一层。

---

# 13. Scene Geometry 与 Camera 必须分开

当前不同图源：

```text
简单图很大
复杂图很小
```

不能用调整 Scene Geometry 解决。

必须确认：

```text
Scene Geometry = BEH_WORLD
Camera = pan + zoom
```

初次显示建议：

```text
initialZoom = min(1.0, fitZoom)
```

但本专项中：

> 先确认原生视觉保真，再确认 Camera 是否造成额外观感失真。

禁止把 Camera 问题误判成 Native Scene Geometry 问题。

---

# 14. Minimal Raw SVG Web Embed 要求

D 层测试页面必须：

```text
无 React/Sprotty 特殊转换
无额外 SVG 重绘
无 Relation 重建
无 Annotation
无 Analysis Overlay
无自动 Fit
无自动 Layout
```

只做：

```text
load raw scene.svg
display
```

并记录：

```text
浏览器
viewport
DPI
字体
SVG DOM
```

---

# 15. Playwright 在本专项中的职责

Playwright 只验证 Web 层：

```text
D. Minimal Raw SVG Web Embed
E. Current Workbench
```

Playwright 不负责证明：

```text
原始 BEH Java Renderer 语义
```

至少验证：

```text
SVG DOM 是否完整
marker/defs 是否存在
Arrow 是否可见
viewBox 是否一致
Node/Relation count 是否一致
CSS 是否覆盖
Workbench 前后 DOM 差异
```

---

# 16. 本轮必须产出的文件

开发模型本轮必须输出：

```text
01_native_render_pipeline.md
02_renderer_reuse_responsibility_matrix.md
03_visual_fidelity_layer_diff.md
04_arrow_render_chain.md
05_icondescription_scope_analysis.md
06_jcanvas_vs_renderer_dependency.md
07_headless_renderer_reuse_assessment.md
08_root_cause_conclusion.md
```

如果可以生成对照产物，还需：

```text
artifacts/
├── A_native_reference.*
├── B_headless_scene.json
├── C_headless_raw_scene.svg
├── D_raw_svg_web_embed.png
├── E_current_workbench.png
└── diff/
```

---

# 17. 本轮测试要求

至少：

```text
[ ] B scene.json Schema PASS
[ ] C raw scene.svg 可独立打开
[ ] B/C Node 数量一致
[ ] B/C Relation 数量一致
[ ] B/C Arrow 信息一致
[ ] C/D SVG DOM 保真
[ ] D/E 差异可定位
[ ] Arrow 丢失层已明确
[ ] first_divergence_layer 已明确
```

---

# 18. 本轮完成门禁

以下问题全部有明确答案之前：

```text
不得继续新增 AI Explain
不得继续 Code Intelligence
不得继续 Compose
不得继续视觉精修
不得继续在 Web 里补原生语义
```

必须明确回答：

1. 当前 Headless Full Scene 是否真正复用了最终原生 Renderer？
2. 如果没有，当前只复用了哪些层？
3. 第一次视觉差异出现在 A/B/C/D/E 哪一层？
4. Arrow 第一次在哪一层丢失？
5. `_icondescription` 是否只是局部 Icon 描述？
6. JCanvas 下方是否存在可独立调用的 Painter / Renderer？
7. 能否用同一套 Painter 做 Offscreen / SVG 输出？
8. Workbench 的 Camera / Fit 是否进一步放大了视觉差异？

---

# 19. 修复阶段规则

本文件只负责：

```text
定位
证明
分类
```

本轮不要求大规模重构。

完成根因报告后，再进入独立修复任务。

修复必须针对：

```text
首次产生差异的那一层
```

禁止在后续层补偿前一层错误。

例如：

```text
C层缺Arrow
```

则禁止：

```text
E层Web补Arrow
```

---

# 20. 最终原则

> **不要让最终 Web “看起来像 BEH”；要证明最终 Web 展示的是 BEH 原生渲染事实经过最少损失后的结果。**

如果当前实现只是：

```text
原生 Parser
+
原生 Icon
+
自研 Scene Composition
```

则必须明确承认：

```text
这不是完整 Native Renderer Reuse
```

然后再决定如何提升到真正的原生渲染复用。
